CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS usuarios (
  id SERIAL PRIMARY KEY,
  nome VARCHAR(200) NOT NULL,
  email VARCHAR(200) NOT NULL UNIQUE,
  senha_hash TEXT NOT NULL,
  perfil VARCHAR(50) NOT NULL DEFAULT 'Consulta',
  ativo BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS eleicoes (
  id SERIAL PRIMARY KEY,
  nome VARCHAR(200) NOT NULL,
  tipo VARCHAR(100) NOT NULL,
  data DATE NOT NULL,
  local VARCHAR(200) NOT NULL,
  quantidade_secoes INTEGER DEFAULT 0,
  quantidade_urnas INTEGER DEFAULT 0,
  status VARCHAR(50) DEFAULT 'Não iniciada',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS candidatos (
  id SERIAL PRIMARY KEY,
  eleicao_id INTEGER NOT NULL REFERENCES eleicoes(id) ON DELETE CASCADE,
  numero INTEGER NOT NULL,
  nome VARCHAR(200) NOT NULL,
  nome_urna VARCHAR(200) NOT NULL,
  partido VARCHAR(150) NOT NULL,
  cargo VARCHAR(100) NOT NULL,
  foto TEXT,
  ativo BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS secoes (
  id SERIAL PRIMARY KEY,
  eleicao_id INTEGER NOT NULL REFERENCES eleicoes(id) ON DELETE CASCADE,
  numero VARCHAR(100) NOT NULL,
  urna INTEGER NOT NULL,
  local VARCHAR(200) NOT NULL,
  zona VARCHAR(100) NOT NULL,
  municipio VARCHAR(150) NOT NULL,
  eleitores_aptos INTEGER NOT NULL DEFAULT 0,
  status VARCHAR(50) DEFAULT 'Aguardando'
);

ALTER TABLE secoes ALTER COLUMN numero TYPE VARCHAR(100) USING numero::text;

CREATE TABLE IF NOT EXISTS apuracoes (
  id SERIAL PRIMARY KEY,
  eleicao_id INTEGER NOT NULL REFERENCES eleicoes(id) ON DELETE CASCADE,
  secao_id INTEGER NOT NULL REFERENCES secoes(id) ON DELETE CASCADE,
  comparecimento INTEGER NOT NULL DEFAULT 0,
  abstencoes INTEGER NOT NULL DEFAULT 0,
  votos_validos INTEGER NOT NULL DEFAULT 0,
  votos_brancos INTEGER NOT NULL DEFAULT 0,
  votos_nulos INTEGER NOT NULL DEFAULT 0,
  status VARCHAR(50) DEFAULT 'Aguardando',
  usuario_lancamento INTEGER REFERENCES usuarios(id),
  usuario_conferencia INTEGER REFERENCES usuarios(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS votos (
  id SERIAL PRIMARY KEY,
  apuracao_id INTEGER NOT NULL REFERENCES apuracoes(id) ON DELETE CASCADE,
  candidato_id INTEGER NOT NULL REFERENCES candidatos(id) ON DELETE CASCADE,
  quantidade INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS logs (
  id SERIAL PRIMARY KEY,
  usuario_id INTEGER REFERENCES usuarios(id),
  tabela VARCHAR(100) NOT NULL,
  registro_id INTEGER,
  acao VARCHAR(100) NOT NULL,
  valor_anterior TEXT,
  valor_novo TEXT,
  motivo TEXT,
  ip VARCHAR(100),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS unique_apuracao_secao
  ON apuracoes (eleicao_id, secao_id);

CREATE INDEX IF NOT EXISTS idx_candidatos_eleicao ON candidatos(eleicao_id);
CREATE INDEX IF NOT EXISTS idx_secoes_eleicao ON secoes(eleicao_id);
CREATE INDEX IF NOT EXISTS idx_apuracoes_eleicao ON apuracoes(eleicao_id);
CREATE INDEX IF NOT EXISTS idx_logs_usuario ON logs(usuario_id);

CREATE TABLE IF NOT EXISTS cargos_bu (
  id SERIAL PRIMARY KEY,
  codigo INTEGER NOT NULL UNIQUE,
  nome VARCHAR(150) NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

INSERT INTO cargos_bu (codigo, nome) VALUES
  (1, 'Presidente'), (3, 'Governador'), (5, 'Senador'),
  (6, 'Deputado Federal'), (7, 'Deputado Estadual'),
  (8, 'Deputado Distrital'), (9, 'Conselheiro Distrital'),
  (11, 'Prefeito'), (13, 'Vereador')
ON CONFLICT (codigo) DO NOTHING;

CREATE TABLE IF NOT EXISTS partidos_bu (
  id SERIAL PRIMARY KEY,
  eleicao_id INTEGER REFERENCES eleicoes(id) ON DELETE CASCADE,
  numero INTEGER,
  sigla VARCHAR(30),
  nome VARCHAR(200),
  dados_originais JSONB,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS candidaturas_bu (
  id SERIAL PRIMARY KEY,
  eleicao_id INTEGER REFERENCES eleicoes(id) ON DELETE CASCADE,
  codigo VARCHAR(80) NOT NULL,
  numero VARCHAR(30),
  nome VARCHAR(200),
  partido_id INTEGER REFERENCES partidos_bu(id) ON DELETE SET NULL,
  cargo_id INTEGER REFERENCES cargos_bu(id) ON DELETE SET NULL,
  situacao VARCHAR(50) DEFAULT 'Ativa',
  dados_originais JSONB,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE (eleicao_id, codigo)
);

CREATE TABLE IF NOT EXISTS boletins_bu (
  id BIGSERIAL PRIMARY KEY,
  eleicao_id INTEGER REFERENCES eleicoes(id) ON DELETE SET NULL,
  processo_eleitoral VARCHAR(100),
  data_pleito DATE,
  turno INTEGER,
  fase VARCHAR(100),
  uf VARCHAR(10),
  municipio VARCHAR(200),
  zona VARCHAR(30),
  secao VARCHAR(30),
  agregacao VARCHAR(100),
  id_urna VARCHAR(120),
  id_carga VARCHAR(120),
  versao VARCHAR(100),
  eleitores_aptos INTEGER,
  comparecimento INTEGER,
  faltosos INTEGER,
  votos_nominais INTEGER,
  votos_legenda INTEGER,
  votos_brancos INTEGER,
  votos_nulos INTEGER,
  total_votos INTEGER,
  status VARCHAR(40) NOT NULL DEFAULT 'PENDENTE',
  hash_original TEXT,
  hash_calculado TEXT,
  hash_status VARCHAR(60) DEFAULT 'REQUIRES CONFIGURATION / DOCUMENTATION',
  assinatura TEXT,
  assinatura_status VARCHAR(60) DEFAULT 'REQUIRES CONFIGURATION / DOCUMENTATION',
  arquivo_original BYTEA,
  nome_arquivo VARCHAR(255),
  conteudo_qr_original TEXT NOT NULL,
  dados_reconstruidos TEXT,
  dados_processados JSONB,
  erros JSONB,
  fingerprint VARCHAR(128) NOT NULL UNIQUE,
  usuario_id INTEGER REFERENCES usuarios(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS qr_codes_bu (
  id BIGSERIAL PRIMARY KEY,
  boletim_id BIGINT NOT NULL REFERENCES boletins_bu(id) ON DELETE CASCADE,
  indice INTEGER NOT NULL,
  quantidade_total INTEGER,
  conteudo TEXT NOT NULL,
  campos JSONB,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE (boletim_id, indice)
);

CREATE TABLE IF NOT EXISTS votos_bu (
  id BIGSERIAL PRIMARY KEY,
  boletim_id BIGINT NOT NULL REFERENCES boletins_bu(id) ON DELETE CASCADE,
  cargo_codigo INTEGER,
  tipo VARCHAR(30) NOT NULL DEFAULT 'NOMINAL',
  partido VARCHAR(80),
  candidato_codigo VARCHAR(80),
  candidato_id INTEGER REFERENCES candidaturas_bu(id) ON DELETE SET NULL,
  quantidade INTEGER NOT NULL CHECK (quantidade >= 0),
  dados_originais JSONB
);

CREATE TABLE IF NOT EXISTS validacoes_bu (
  id BIGSERIAL PRIMARY KEY,
  boletim_id BIGINT NOT NULL REFERENCES boletins_bu(id) ON DELETE CASCADE,
  tipo VARCHAR(30) NOT NULL,
  resultado VARCHAR(60) NOT NULL,
  valor_original TEXT,
  valor_calculado TEXT,
  detalhes TEXT,
  usuario_id INTEGER REFERENCES usuarios(id),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS importacoes_bu (
  id BIGSERIAL PRIMARY KEY,
  nome_arquivo VARCHAR(255),
  tipo VARCHAR(40) NOT NULL,
  versao VARCHAR(80),
  status VARCHAR(40) NOT NULL,
  quantidade_registros INTEGER DEFAULT 0,
  erros JSONB,
  conteudo_original JSONB,
  usuario_id INTEGER REFERENCES usuarios(id),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_boletins_bu_eleicao ON boletins_bu(eleicao_id);
CREATE INDEX IF NOT EXISTS idx_boletins_bu_local ON boletins_bu(municipio, zona, secao);
CREATE INDEX IF NOT EXISTS idx_boletins_bu_status ON boletins_bu(status);
CREATE INDEX IF NOT EXISTS idx_votos_bu_boletim ON votos_bu(boletim_id);
