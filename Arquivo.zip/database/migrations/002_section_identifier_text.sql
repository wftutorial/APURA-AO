-- Permite identificar a seção por número ou nome, mantendo os valores existentes.
ALTER TABLE secoes
  ALTER COLUMN numero TYPE VARCHAR(100)
  USING numero::text;
