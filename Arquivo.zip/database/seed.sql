-- Usuário administrador inicial
INSERT INTO usuarios (nome, email, senha_hash, perfil, ativo, created_at)
VALUES (
  'Administrador',
  'admin@apuracao.local',
  '$2b$10$532NBwPCM8pWAL6enKLdG.LKmr.Ulp.rKnNvrGX2DYTYZTgeUZKa.',
  'Administrador',
  true,
  NOW()
)
ON CONFLICT (email) DO NOTHING;

-- Eleição de teste
INSERT INTO eleicoes (nome, tipo, data, local, quantidade_secoes, quantidade_urnas, status, created_at)
VALUES (
  'Eleição Municipal de Teste',
  'Municipal',
  '2026-10-15',
  'São Paulo',
  10,
  10,
  'Em andamento',
  NOW()
)
ON CONFLICT DO NOTHING;

-- candidatos
INSERT INTO candidatos (eleicao_id, numero, nome, nome_urna, partido, cargo, foto, ativo)
VALUES
  (1, 10, 'Candidato A', 'Candidato A', 'Partido X', 'Prefeito', NULL, true),
  (1, 20, 'Candidato B', 'Candidato B', 'Partido Y', 'Prefeito', NULL, true),
  (1, 30, 'Candidato C', 'Candidato C', 'Partido Z', 'Prefeito', NULL, true),
  (1, 40, 'Candidato D', 'Candidato D', 'Partido W', 'Prefeito', NULL, true),
  (1, 50, 'Candidato E', 'Candidato E', 'Partido Q', 'Prefeito', NULL, true)
ON CONFLICT DO NOTHING;

-- seções fictícias
INSERT INTO secoes (eleicao_id, numero, urna, local, zona, municipio, eleitores_aptos, status)
VALUES
  (1, '101', 1, 'Escola A', '001', 'São Paulo', 450, 'Aguardando'),
  (1, '102', 2, 'Escola B', '001', 'São Paulo', 420, 'Aguardando'),
  (1, '103', 3, 'Escola C', '002', 'São Paulo', 500, 'Aguardando'),
  (1, '104', 4, 'Escola D', '002', 'São Paulo', 470, 'Em apuração'),
  (1, '105', 5, 'Escola E', '003', 'São Paulo', 430, 'Aguardando'),
  (1, '106', 6, 'Escola F', '003', 'São Paulo', 490, 'Aguardando'),
  (1, '107', 7, 'Escola G', '004', 'São Paulo', 460, 'Aguardando'),
  (1, '108', 8, 'Escola H', '004', 'São Paulo', 520, 'Aguardando'),
  (1, '109', 9, 'Escola I', '005', 'São Paulo', 410, 'Aguardando'),
  (1, '110', 10, 'Escola J', '005', 'São Paulo', 480, 'Aguardando')
ON CONFLICT DO NOTHING;

-- Dados de apuração de exemplo para uma seção
INSERT INTO apuracoes (eleicao_id, secao_id, comparecimento, abstencoes, votos_validos, votos_brancos, votos_nulos, status, usuario_lancamento, usuario_conferencia, created_at, updated_at)
VALUES (1, 4, 320, 50, 260, 40, 20, 'Conferida', 1, 1, NOW(), NOW())
ON CONFLICT DO NOTHING;

INSERT INTO votos (apuracao_id, candidato_id, quantidade)
VALUES
  (1, 1, 110),
  (1, 2, 92),
  (1, 3, 33),
  (1, 4, 18),
  (1, 5, 7)
ON CONFLICT DO NOTHING;
