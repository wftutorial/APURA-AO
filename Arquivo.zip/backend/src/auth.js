const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

if (process.env.NODE_ENV === 'production' && !process.env.JWT_SECRET) {
  throw new Error('JWT_SECRET precisa estar configurado em produção.');
}

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret';

const hashPassword = async (password) => bcrypt.hash(password, 10);
const comparePassword = async (password, hash) => bcrypt.compare(password, hash);
const signToken = (user) => jwt.sign({ id: user.id, perfil: user.perfil, email: user.email }, JWT_SECRET, { expiresIn: '8h' });

const requireAuth = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ message: 'Token de autenticação obrigatório.' });
  }

  const token = authHeader.split(' ')[1];
  if (!token) {
    return res.status(401).json({ message: 'Formato de token inválido.' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Token inválido ou expirado.' });
  }
};

const requireRole = (...allowedRoles) => (req, res, next) => {
  if (!req.user || !allowedRoles.includes(req.user.perfil)) {
    return res.status(403).json({ message: 'Você não tem permissão para acessar este recurso.' });
  }
  next();
};

module.exports = { hashPassword, comparePassword, signToken, requireAuth, requireRole };
