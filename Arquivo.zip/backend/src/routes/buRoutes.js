const express = require('express');
const multer = require('multer');
const crypto = require('crypto');
const router = express.Router();
const { pool, query } = require('../db');
const { requireAuth, requireRole } = require('../auth');
const { reconstruct } = require('../services/qrReconstructor');
const { parse } = require('../services/buParser');
const { validate, validateHash, validateSignature } = require('../services/buValidator');

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 },
});

router.use(requireAuth);

function readQrCodes(body) {
  if (Array.isArray(body.qr_codes)) return body.qr_codes;
  if (body.qr_codes) {
    try { return JSON.parse(body.qr_codes); } catch (error) { return [body.qr_codes]; }
  }
  if (body.conteudo || body.content) return [body.conteudo || body.content];
  return [];
}

async function importBu(req, res) {
  const qrCodes = readQrCodes(req.body || {});
  const reconstruction = reconstruct(qrCodes);
  const parsed = parse(reconstruction.content);
  const validation = validate(parsed, reconstruction);
  const fingerprint = qrCodes.length
    ? reconstruction.fingerprint
    : crypto.createHash('sha512').update(req.file?.buffer || '').digest('hex');

  if (!reconstruction.complete) {
    if (req.file) {
      try {
        const pending = await query(
          `INSERT INTO boletins_bu (eleicao_id, status, arquivo_original, nome_arquivo, conteudo_qr_original, dados_reconstruidos, dados_processados, erros, fingerprint, usuario_id)
           VALUES ($1,'PENDENTE',$2,$3,$4,$5,$6,$7,$8,$9)
           ON CONFLICT (fingerprint) DO UPDATE SET updated_at = NOW()
           RETURNING id, status, nome_arquivo, created_at`,
          [req.body.eleicao_id || null, req.file.buffer, req.file.originalname, '', '', JSON.stringify(parsed), JSON.stringify(['QR Codes não decodificados; REQUIRES CONFIGURATION / DOCUMENTATION']), fingerprint, req.user.id]
        );
        return res.status(201).json({ message: 'Arquivo preservado como BU pendente; os QR Codes ainda precisam ser decodificados.', boletim: pending.rows[0], reconstruction, parsed, validation });
      } catch (error) {
        console.error(error);
        return res.status(500).json({ message: 'Não foi possível preservar o arquivo do BU.' });
      }
    }
    return res.status(422).json({
      message: 'BU incompleto. Envie todos os QR Codes antes de importar.',
      reconstruction,
      parsed,
      validation,
    });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const existing = await client.query('SELECT id, status, created_at, usuario_id FROM boletins_bu WHERE fingerprint = $1', [fingerprint]);
    if (existing.rows.length) {
      await client.query('ROLLBACK');
      return res.status(409).json({ message: 'Boletim já importado.', duplicate: existing.rows[0] });
    }

    const result = await client.query(
      `INSERT INTO boletins_bu (
        eleicao_id, processo_eleitoral, data_pleito, turno, fase, uf, municipio, zona, secao,
        agregacao, id_urna, id_carga, versao, eleitores_aptos, comparecimento, faltosos,
        votos_nominais, votos_legenda, votos_brancos, votos_nulos, total_votos, status,
        hash_original, hash_calculado, hash_status, assinatura, assinatura_status,
        arquivo_original, nome_arquivo, conteudo_qr_original, dados_reconstruidos,
        dados_processados, erros, fingerprint, usuario_id
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35)
      RETURNING *`,
      [
        req.body.eleicao_id || null, parsed.processo_eleitoral, parsed.data_pleito || null, parsed.turno,
        parsed.fase, parsed.uf, parsed.municipio, parsed.zona, parsed.secao, parsed.agregacao,
        parsed.id_urna, parsed.id_carga, parsed.versao, parsed.eleitores_aptos, parsed.comparecimento,
        parsed.faltosos, parsed.votos_nominais, parsed.votos_legenda, parsed.votos_brancos,
        parsed.votos_nulos, parsed.total_votos, validation.status, parsed.hash_original,
        validation.hash.calculated, validation.hash.status, parsed.assinatura, validation.signature.status,
        req.file?.buffer || null, req.file?.originalname || null, qrCodes.map((item) => String(item?.content ?? item?.conteudo ?? item ?? '')).join('\n'),
        reconstruction.content, parsed, validation.errors, fingerprint, req.user.id,
      ]
    );
    const boletim = result.rows[0];

    for (const item of reconstruction.items) {
      await client.query(
        `INSERT INTO qr_codes_bu (boletim_id, indice, quantidade_total, conteudo, campos)
         VALUES ($1,$2,$3,$4,$5)`,
        [boletim.id, item.index, item.total, item.content, parse(item.content).fields]
      );
    }
    await client.query(
      `INSERT INTO validacoes_bu (boletim_id, tipo, resultado, valor_original, valor_calculado, detalhes, usuario_id)
       VALUES ($1,'HASH',$2,$3,$4,$5,$6),($1,'ASSI',$7,$8,NULL,$9,$6)`,
      [boletim.id, validation.hash.status, parsed.hash_original, validation.hash.calculated, validation.hash.details, req.user.id,
        validation.signature.status, parsed.assinatura, validation.signature.details]
    );
    await client.query(
      `INSERT INTO logs (usuario_id, tabela, registro_id, acao, valor_novo, ip)
       VALUES ($1, 'boletins_bu', $2, 'IMPORTACAO', $3, $4)`,
      [req.user.id, boletim.id, JSON.stringify({ status: boletim.status, fingerprint }), req.ip]
    );
    await client.query('COMMIT');
    return res.status(201).json({ boletim, reconstruction, parsed, validation });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error(error);
    return res.status(500).json({ message: 'Erro ao importar boletim de urna.' });
  } finally {
    client.release();
  }
}

router.post('/importar', requireRole('Administrador', 'Apurador'), upload.single('file'), importBu);
router.post('/ler-qrcode', requireRole('Administrador', 'Apurador'), importBu);
router.post('/qrcode/scan', requireRole('Administrador', 'Apurador'), importBu);
router.post('/reconstruct', requireRole('Administrador', 'Apurador'), (req, res) => {
  const reconstruction = reconstruct(readQrCodes(req.body || {}));
  res.json(reconstruction);
});

router.post('/reprocessar', requireRole('Administrador', 'Apurador'), async (req, res) => {
  const client = await pool.connect();
  try {
    const source = await client.query('SELECT * FROM boletins_bu WHERE id = $1', [req.body?.id]);
    if (!source.rows.length) return res.status(404).json({ message: 'Boletim não encontrado.' });
    const qr = await client.query('SELECT * FROM qr_codes_bu WHERE boletim_id = $1 ORDER BY indice', [req.body.id]);
    const reconstruction = reconstruct(qr.rows.map((item) => ({ index: item.indice, total: item.quantidade_total, content: item.conteudo })));
    const parsed = parse(reconstruction.content);
    const validation = validate(parsed, reconstruction);
    const updated = await client.query(
      `UPDATE boletins_bu SET municipio=$1, zona=$2, secao=$3, turno=$4, eleitores_aptos=$5, comparecimento=$6,
       faltosos=$7, votos_nominais=$8, votos_legenda=$9, votos_brancos=$10, votos_nulos=$11, total_votos=$12,
       status=$13, dados_reconstruidos=$14, dados_processados=$15, erros=$16, updated_at=NOW() WHERE id=$17 RETURNING *`,
      [parsed.municipio, parsed.zona, parsed.secao, parsed.turno, parsed.eleitores_aptos, parsed.comparecimento,
        parsed.faltosos, parsed.votos_nominais, parsed.votos_legenda, parsed.votos_brancos, parsed.votos_nulos,
        parsed.total_votos, validation.status, reconstruction.content, parsed, validation.errors, req.body.id]
    );
    res.json({ boletim: updated.rows[0], reconstruction, parsed, validation });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro ao reprocessar boletim.' });
  } finally {
    client.release();
  }
});

router.get('/dashboard/summary', async (req, res) => {
  try {
    const result = await query(`SELECT
      COUNT(*)::INTEGER AS boletins,
      COUNT(*) FILTER (WHERE status = 'VALIDO')::INTEGER AS validos,
      COUNT(*) FILTER (WHERE status = 'INVALIDO')::INTEGER AS invalidos,
      COUNT(*) FILTER (WHERE status = 'PENDENTE')::INTEGER AS pendentes,
      COUNT(DISTINCT secao)::INTEGER AS secoes,
      COUNT(DISTINCT zona)::INTEGER AS zonas,
      COUNT(DISTINCT municipio)::INTEGER AS municipios,
      COALESCE(SUM(eleitores_aptos) FILTER (WHERE status = 'VALIDO'), 0)::INTEGER AS eleitores_aptos,
      COALESCE(SUM(comparecimento) FILTER (WHERE status = 'VALIDO'), 0)::INTEGER AS comparecimento,
      COALESCE(SUM(faltosos) FILTER (WHERE status = 'VALIDO'), 0)::INTEGER AS faltosos,
      COALESCE(SUM(total_votos) FILTER (WHERE status = 'VALIDO'), 0)::INTEGER AS total_votos,
      COALESCE(SUM(votos_brancos) FILTER (WHERE status = 'VALIDO'), 0)::INTEGER AS votos_brancos,
      COALESCE(SUM(votos_nulos) FILTER (WHERE status = 'VALIDO'), 0)::INTEGER AS votos_nulos
      FROM boletins_bu WHERE ($1::INTEGER IS NULL OR eleicao_id = $1)`, [req.query.eleicao_id || null]);
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao consultar resumo de BUs.' });
  }
});

router.delete('/:id', requireRole('Administrador'), async (req, res) => {
  try {
    const result = await query('DELETE FROM boletins_bu WHERE id = $1 RETURNING id', [req.params.id]);
    if (!result.rows.length) return res.status(404).json({ message: 'Boletim não encontrado.' });
    await query('INSERT INTO logs (usuario_id, tabela, registro_id, acao, ip) VALUES ($1,\'boletins_bu\',$2,\'EXCLUSAO\',$3)', [req.user.id, req.params.id, req.ip]);
    res.json({ message: 'Boletim removido.' });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao excluir boletim.' });
  }
});

router.get('/', async (req, res) => {
  try {
    const { eleicao_id, status, municipio, zona, secao } = req.query;
    const conditions = [];
    const params = [];
    for (const [column, value] of [['eleicao_id', eleicao_id], ['status', status], ['municipio', municipio], ['zona', zona], ['secao', secao]]) {
      if (value) { params.push(value); conditions.push(`${column} = $${params.length}`); }
    }
    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const result = await query(`SELECT id, eleicao_id, municipio, zona, secao, turno, status, eleitores_aptos, comparecimento, faltosos, votos_brancos, votos_nulos, hash_status, assinatura_status, created_at FROM boletins_bu ${where} ORDER BY created_at DESC`, params);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao listar boletins.' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const result = await query('SELECT * FROM boletins_bu WHERE id = $1', [req.params.id]);
    if (!result.rows.length) return res.status(404).json({ message: 'Boletim não encontrado.' });
    const qr = await query('SELECT * FROM qr_codes_bu WHERE boletim_id = $1 ORDER BY indice', [req.params.id]);
    const validations = await query('SELECT * FROM validacoes_bu WHERE boletim_id = $1 ORDER BY created_at DESC', [req.params.id]);
    res.json({ boletim: result.rows[0], qr_codes: qr.rows, validacoes: validations.rows });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao consultar boletim.' });
  }
});

router.put('/:id', requireRole('Administrador', 'Apurador'), async (req, res) => {
  const { municipio, zona, secao, turno, fase, uf, status } = req.body || {};
  try {
    const result = await query(
      `UPDATE boletins_bu SET municipio=COALESCE($1, municipio), zona=COALESCE($2, zona), secao=COALESCE($3, secao),
       turno=COALESCE($4, turno), fase=COALESCE($5, fase), uf=COALESCE($6, uf), status=COALESCE($7, status), updated_at=NOW()
       WHERE id=$8 RETURNING id, municipio, zona, secao, turno, fase, uf, status, updated_at`,
      [municipio, zona, secao, turno !== undefined ? Number(turno) : null, fase, uf, status, req.params.id]
    );
    if (!result.rows.length) return res.status(404).json({ message: 'Boletim não encontrado.' });
    await query(
      `INSERT INTO logs (usuario_id, tabela, registro_id, acao, valor_novo, ip, created_at)
       VALUES ($1, 'boletins_bu', $2, 'alteracao_metadados', $3, $4, NOW())`,
      [req.user.id, req.params.id, JSON.stringify(result.rows[0]), req.ip]
    );
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao alterar metadados do BU.' });
  }
});

router.post('/:id/validar-hash', requireRole('Administrador', 'Apurador'), async (req, res) => {
  res.status(501).json({ message: 'REQUIRES CONFIGURATION / DOCUMENTATION: algoritmo canônico do HASH do BU não fornecido.' });
});

router.post('/:id/validar-assinatura', requireRole('Administrador', 'Apurador'), async (req, res) => {
  res.status(501).json({ message: 'REQUIRES CONFIGURATION / DOCUMENTATION: chave pública e parâmetros Ed25519/EdDSA não fornecidos.' });
});

router.post('/:id/validar', requireRole('Administrador', 'Apurador'), async (req, res) => {
  res.status(501).json({ message: 'Validação criptográfica pendente da documentação técnica oficial.' });
});

module.exports = router;
