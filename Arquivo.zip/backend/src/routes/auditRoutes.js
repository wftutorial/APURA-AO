const express = require('express');
const router = express.Router();
const { query } = require('../db');
const { requireAuth, requireRole } = require('../auth');

router.use(requireAuth);
router.use(requireRole('Administrador'));

router.get('/', async (req, res) => {
  try {
    const result = await query(
      `SELECT l.*, u.nome AS usuario_nome
       FROM logs l
       LEFT JOIN usuarios u ON u.id = l.usuario_id
       ORDER BY l.created_at DESC LIMIT 200`
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao consultar auditoria.' });
  }
});

module.exports = router;
