const express = require('express');
const router = express.Router();
const { query } = require('../db');
const { hashPassword, comparePassword, signToken, requireAuth, requireRole } = require('../auth');

router.post('/login', async (req, res) => {
  const { email, senha } = req.body || {};

  if (!email || !senha) {
    return res.status(400).json({ message: 'E-mail e senha são obrigatórios.' });
  }

  try {
    const result = await query(
      'SELECT * FROM usuarios WHERE email = $1 AND ativo = true LIMIT 1',
      [email.trim().toLowerCase()]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ message: 'Credenciais inválidas.' });
    }

    const user = result.rows[0];
    const isValid = await comparePassword(senha, user.senha_hash);
    if (!isValid) {
      return res.status(401).json({ message: 'Credenciais inválidas.' });
    }

    const token = signToken(user);
    return res.json({
      token,
      user: {
        id: user.id,
        nome: user.nome,
        email: user.email,
        perfil: user.perfil,
      },
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Erro ao tentar autenticar.' });
  }
});

router.get('/me', requireAuth, async (req, res) => {
  try {
    const result = await query('SELECT id, nome, email, perfil, ativo FROM usuarios WHERE id = $1', [req.user.id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Usuário não encontrado.' });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao consultar usuário.' });
  }
});

router.post('/reset-password', async (req, res) => {
  const { email } = req.body || {};
  if (!email) {
    return res.status(400).json({ message: 'E-mail obrigatório.' });
  }

  res.json({ message: 'Se o e-mail estiver cadastrado, uma recuperação será enviada.' });
});

router.get('/admin-check', requireAuth, requireRole('Administrador'), (req, res) => {
  res.json({ ok: true, access: 'admin' });
});

router.post('/register', requireAuth, requireRole('Administrador'), async (req, res) => {
  const { nome, email, senha, perfil = 'Consulta' } = req.body || {};

  if (!nome || !email || !senha) {
    return res.status(400).json({ message: 'Nome, e-mail e senha são obrigatórios.' });
  }

  try {
    const exists = await query('SELECT 1 FROM usuarios WHERE email = $1 LIMIT 1', [email.trim().toLowerCase()]);
    if (exists.rows.length > 0) {
      return res.status(409).json({ message: 'Já existe um usuário com este e-mail.' });
    }

    const senhaHash = await hashPassword(senha);
    const result = await query(
      `INSERT INTO usuarios (nome, email, senha_hash, perfil, ativo, created_at)
       VALUES ($1,$2,$3,$4,true,NOW()) RETURNING id, nome, email, perfil`,
      [nome, email.trim().toLowerCase(), senhaHash, perfil]
    );

    return res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Erro ao cadastrar usuário.' });
  }
});

module.exports = router;
