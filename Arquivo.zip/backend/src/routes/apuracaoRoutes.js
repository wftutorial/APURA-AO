const express = require('express');
const router = express.Router();
const { query, pool } = require('../db');
const { requireAuth, requireRole } = require('../auth');

router.use(requireAuth);

router.get('/by-election/:eleicaoId', async (req, res) => {
  try {
    const result = await query(
      `SELECT a.*, s.numero AS secao_numero, s.local, s.zona, s.urna
       FROM apuracoes a
       LEFT JOIN secoes s ON s.id = a.secao_id
       WHERE a.eleicao_id = $1
       ORDER BY s.numero`,
      [req.params.eleicaoId]
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao listar apurações.' });
  }
});

router.get('/section/:secaoId', async (req, res) => {
  try {
    const result = await query('SELECT * FROM apuracoes WHERE secao_id = $1', [req.params.secaoId]);
    if (!result.rows[0]) return res.json(null);
    const votes = await query('SELECT candidato_id, quantidade FROM votos WHERE apuracao_id = $1', [result.rows[0].id]);
    res.json({ ...result.rows[0], votos: votes.rows });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao buscar apuração da seção.' });
  }
});

router.post('/', requireRole('Administrador', 'Apurador', 'Fiscal'), async (req, res) => {
  const { eleicao_id, secao_id, comparecimento, abstencoes, votos_validos, votos_brancos, votos_nulos, votos = [], usuario_lancamento } = req.body || {};

  if (!eleicao_id || !secao_id) {
    return res.status(400).json({ message: 'Eleição e seção são obrigatórios.' });
  }

  try {
    const existing = await query('SELECT id FROM apuracoes WHERE secao_id = $1 AND eleicao_id = $2 LIMIT 1', [secao_id, eleicao_id]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ message: 'Já existe um lançamento para esta seção. Edite o lançamento existente na lista de apurações.' });
    }

    const secao = await query('SELECT eleitores_aptos FROM secoes WHERE id = $1', [secao_id]);
    const eleitoresAptos = Number(secao.rows[0]?.eleitores_aptos || 0);

    if (Number(comparecimento || 0) > eleitoresAptos) {
      return res.status(400).json({ message: 'Comparecimento não pode ser maior que eleitores aptos.' });
    }

    const totalVotos = Number(votos_validos || 0) + Number(votos_brancos || 0) + Number(votos_nulos || 0);
    if (totalVotos > Number(comparecimento || 0)) {
      return res.status(400).json({ message: 'Votos dos candidatos + brancos + nulos não podem ultrapassar o comparecimento.' });
    }
    const votosIndividuais = (votos || []).reduce((sum, voto) => sum + Number(voto.quantidade || 0), 0);
    if (votosIndividuais !== Number(votos_validos || 0)) {
      return res.status(400).json({ message: `A soma dos votos dos candidatos (${votosIndividuais}) precisa ser igual aos votos válidos (${Number(votos_validos || 0)}).` });
    }

    const result = await query(
      `INSERT INTO apuracoes (eleicao_id, secao_id, comparecimento, abstencoes, votos_validos, votos_brancos, votos_nulos, status, usuario_lancamento, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,NOW(),NOW()) RETURNING *`,
      [eleicao_id, secao_id, Number(comparecimento || 0), Number(abstencoes || 0), Number(votos_validos || 0), Number(votos_brancos || 0), Number(votos_nulos || 0), 'Conferida', usuario_lancamento || req.user.id]
    );

    const apuracaoId = result.rows[0].id;
    for (const voto of votos || []) {
      await query(
        `INSERT INTO votos (apuracao_id, candidato_id, quantidade) VALUES ($1,$2,$3)`,
        [apuracaoId, voto.candidato_id, Number(voto.quantidade || 0)]
      );
    }

    await query("UPDATE secoes SET status = 'Apurada' WHERE id = $1", [secao_id]);

    res.status(201).json({ ...result.rows[0], votos });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro ao registrar apuração.' });
  }
});

router.put('/:id', requireRole('Administrador', 'Apurador'), async (req, res) => {
  const { comparecimento, abstencoes, votos_validos, votos_brancos, votos_nulos, votos = [], motivo = 'Correção autorizada' } = req.body || {};
  let client;

  try {
    const apuracao = await query('SELECT * FROM apuracoes WHERE id = $1', [req.params.id]);
    if (apuracao.rows.length === 0) return res.status(404).json({ message: 'Apuração não encontrada.' });

    const secao = await query('SELECT eleitores_aptos FROM secoes WHERE id = $1', [apuracao.rows[0].secao_id]);
    const eleitoresAptos = Number(secao.rows[0]?.eleitores_aptos || 0);

    if (comparecimento !== undefined && Number(comparecimento) > eleitoresAptos) {
      return res.status(400).json({ message: 'Comparecimento não pode ser maior que eleitores aptos.' });
    }

    const computedValidos = votos_validos !== undefined ? Number(votos_validos) : Number(apuracao.rows[0].votos_validos || 0);
    const computedBrancos = votos_brancos !== undefined ? Number(votos_brancos) : Number(apuracao.rows[0].votos_brancos || 0);
    const computedNulos = votos_nulos !== undefined ? Number(votos_nulos) : Number(apuracao.rows[0].votos_nulos || 0);
    const computedComparecimento = comparecimento !== undefined ? Number(comparecimento) : Number(apuracao.rows[0].comparecimento || 0);

    if (computedValidos + computedBrancos + computedNulos > computedComparecimento) {
      return res.status(400).json({ message: 'Votos dos candidatos + brancos + nulos não podem ultrapassar o comparecimento.' });
    }
    const votosIndividuais = (votos || []).reduce((sum, voto) => sum + Number(voto.quantidade || 0), 0);
    if (votosIndividuais !== computedValidos) {
      return res.status(400).json({ message: `A soma dos votos dos candidatos (${votosIndividuais}) precisa ser igual aos votos válidos (${computedValidos}).` });
    }

    client = await pool.connect();
    await client.query('BEGIN');

    const result = await client.query(
      `UPDATE apuracoes SET comparecimento = COALESCE($1, comparecimento), abstencoes = COALESCE($2, abstencoes), votos_validos = COALESCE($3, votos_validos), votos_brancos = COALESCE($4, votos_brancos), votos_nulos = COALESCE($5, votos_nulos), status = COALESCE($6, status), updated_at = NOW() WHERE id = $7 RETURNING *`,
      [comparecimento !== undefined ? Number(comparecimento) : null, abstencoes !== undefined ? Number(abstencoes) : null, computedValidos, computedBrancos, computedNulos, 'Conferida', req.params.id]
    );

    await client.query('DELETE FROM votos WHERE apuracao_id = $1', [req.params.id]);
    for (const voto of votos) {
      await client.query(
        `INSERT INTO votos (apuracao_id, candidato_id, quantidade) VALUES ($1,$2,$3)`,
        [req.params.id, voto.candidato_id, Number(voto.quantidade || 0)]
      );
    }

    await client.query("UPDATE secoes SET status = 'Apurada' WHERE id = $1", [apuracao.rows[0].secao_id]);

    await client.query(
      `INSERT INTO logs (usuario_id, tabela, registro_id, acao, valor_anterior, valor_novo, motivo, ip, created_at)
       VALUES ($1, 'apuracoes', $2, 'correcao', $3, $4, $5, $6, NOW())`,
      [req.user.id, req.params.id, JSON.stringify(apuracao.rows[0]), JSON.stringify(result.rows[0]), motivo, req.ip || 'unknown']
    );

    await client.query('COMMIT');
    res.json(result.rows[0]);
  } catch (error) {
    if (client) await client.query('ROLLBACK').catch(() => {});
    console.error(error);
    res.status(500).json({ message: 'Erro ao atualizar apuração.' });
  } finally {
    client?.release();
  }
});

router.delete('/:id', requireRole('Administrador'), async (req, res) => {
  try {
    const result = await query('DELETE FROM apuracoes WHERE id = $1 RETURNING id', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ message: 'Apuração não encontrada.' });
    await query(
      `INSERT INTO logs (usuario_id, tabela, registro_id, acao, motivo, ip, created_at)
       VALUES ($1, 'apuracoes', $2, 'exclusao', 'Exclusão administrativa', $3, NOW())`,
      [req.user.id, req.params.id, req.ip || 'unknown']
    );
    res.json({ message: 'Apuração removida com sucesso.' });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao excluir apuração.' });
  }
});

router.post('/:id/conferir', requireRole('Administrador', 'Apurador'), async (req, res) => {
  const { action = 'aprovar', motivo = 'Conferência' } = req.body || {};
  try {
    const result = await query(
      `UPDATE apuracoes SET status = $1, usuario_conferencia = $2, updated_at = NOW() WHERE id = $3 RETURNING *`,
      [action === 'rejeitar' ? 'Rejeitada' : 'Conferida', req.user.id, req.params.id]
    );

    await query(
      `INSERT INTO logs (usuario_id, tabela, registro_id, acao, valor_anterior, valor_novo, motivo, ip, created_at)
       VALUES ($1, 'apuracoes', $2, $3, $4, $5, $6, $7, NOW())`,
      [req.user.id, req.params.id, action, 'pendente', result.rows[0].status, motivo, req.ip || 'unknown']
    );

    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao conferenciar apuração.' });
  }
});

module.exports = router;
