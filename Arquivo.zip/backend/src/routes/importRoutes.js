const express = require('express');
const router = express.Router();
const multer = require('multer');
const xlsx = require('xlsx');
const csv = require('csvtojson');
const fs = require('fs');
const path = require('path');
const { requireAuth, requireRole } = require('../auth');

router.use(requireAuth);
router.use(requireRole('Administrador', 'Apurador'));

const upload = multer({
  dest: path.join(__dirname, '../../uploads'),
  limits: { fileSize: 10 * 1024 * 1024 },
});
const referenceDocument = path.join(__dirname, '../../uploads/qrcode_no_boletim_de_urna.pdf');

router.get('/reference', (req, res) => {
  if (!fs.existsSync(referenceDocument)) {
    return res.status(404).json({ message: 'Documento de referência não encontrado.' });
  }

  const stats = fs.statSync(referenceDocument);
  res.json({
    name: 'qrcode_no_boletim_de_urna.pdf',
    size: stats.size,
    pages: 43,
  });
});

router.get('/reference/file', (req, res) => {
  if (!fs.existsSync(referenceDocument)) {
    return res.status(404).json({ message: 'Documento de referência não encontrado.' });
  }

  res.type('application/pdf').sendFile(referenceDocument);
});

router.post('/preview', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'Arquivo obrigatório.' });
    }

    const ext = path.extname(req.file.originalname).toLowerCase();
    let rows = [];

    if (ext === '.csv') {
      rows = await csv().fromFile(req.file.path);
    } else if (ext === '.xlsx' || ext === '.xls') {
      const workbook = xlsx.readFile(req.file.path);
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      rows = xlsx.utils.sheet_to_json(sheet, { defval: '' });
    } else {
      return res.status(400).json({ message: 'Formato de arquivo não suportado. Use CSV ou Excel.' });
    }

    res.json({
      total: rows.length,
      preview: rows.slice(0, 10),
      valid: rows.length > 0,
      message: 'Prévia gerada com sucesso.',
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro ao ler arquivo importado.' });
  } finally {
    if (req.file?.path) {
      fs.promises.unlink(req.file.path).catch((error) => {
        if (error.code !== 'ENOENT') console.error('Não foi possível remover arquivo temporário:', error);
      });
    }
  }
});

module.exports = router;
