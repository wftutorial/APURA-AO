const express = require('express');
const router = express.Router();
const { query } = require('../db');
const { requireAuth, requireRole } = require('../auth');

router.use(requireAuth);

router.get('/', async (req, res) => {
  try {
    const result = await query('SELECT * FROM eleicoes ORDER BY data DESC, created_at DESC');
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao listar eleições.' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const result = await query('SELECT * FROM eleicoes WHERE id = $1', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ message: 'Eleição não encontrada.' });
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao buscar eleição.' });
  }
});

router.post('/', requireRole('Administrador', 'Apurador'), async (req, res) => {
  const { nome, tipo, data, local, quantidade_secoes, quantidade_urnas, status = 'Não iniciada' } = req.body || {};

  if (!nome || !tipo || !data || !local) {
    return res.status(400).json({ message: 'Nome, tipo, data e local são obrigatórios.' });
  }

  try {
    const result = await query(
      `INSERT INTO eleicoes (nome, tipo, data, local, quantidade_secoes, quantidade_urnas, status, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,NOW()) RETURNING *`,
      [nome, tipo, data, local, Number(quantidade_secoes || 0), Number(quantidade_urnas || 0), status]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro ao criar eleição.' });
  }
});

router.put('/:id', requireRole('Administrador', 'Apurador'), async (req, res) => {
  const { nome, tipo, data, local, quantidade_secoes, quantidade_urnas, status } = req.body || {};
  try {
    const result = await query(
      `UPDATE eleicoes SET nome = COALESCE($1, nome), tipo = COALESCE($2, tipo), data = COALESCE($3, data), local = COALESCE($4, local), quantidade_secoes = COALESCE($5, quantidade_secoes), quantidade_urnas = COALESCE($6, quantidade_urnas), status = COALESCE($7, status), created_at = created_at WHERE id = $8 RETURNING *`,
      [nome, tipo, data, local, quantidade_secoes !== undefined ? Number(quantidade_secoes) : null, quantidade_urnas !== undefined ? Number(quantidade_urnas) : null, status, req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ message: 'Eleição não encontrada.' });
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao atualizar eleição.' });
  }
});

router.delete('/:id', requireRole('Administrador'), async (req, res) => {
  try {
    const result = await query('DELETE FROM eleicoes WHERE id = $1 RETURNING *', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ message: 'Eleição não encontrada.' });
    res.json({ message: 'Eleição removida com sucesso.' });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao excluir eleição.' });
  }
});

module.exports = router;
