const express = require('express');
const router = express.Router();
const { query } = require('../db');
const { requireAuth } = require('../auth');

router.use(requireAuth);

router.get('/export/:eleicaoId', async (req, res) => {
  try {
    const report = await query(
      `SELECT e.id, e.nome, e.tipo, e.local, e.data,
              (SELECT COUNT(*) FROM secoes s WHERE s.eleicao_id = e.id) AS total_secoes,
              (SELECT COUNT(*) FROM apuracoes a WHERE a.eleicao_id = e.id) AS apuradas,
              (SELECT COALESCE(SUM(s.eleitores_aptos),0) FROM secoes s WHERE s.eleicao_id = e.id) AS eleitores_aptos,
              (SELECT COALESCE(SUM(a.comparecimento),0) FROM apuracoes a WHERE a.eleicao_id = e.id) AS comparecimento,
              (SELECT COALESCE(SUM(a.abstencoes),0) FROM apuracoes a WHERE a.eleicao_id = e.id) AS abstencoes,
              (SELECT COALESCE(SUM(a.votos_validos),0) FROM apuracoes a WHERE a.eleicao_id = e.id) AS votos_validos,
              (SELECT COALESCE(SUM(a.votos_brancos),0) FROM apuracoes a WHERE a.eleicao_id = e.id) AS votos_brancos,
              (SELECT COALESCE(SUM(a.votos_nulos),0) FROM apuracoes a WHERE a.eleicao_id = e.id) AS votos_nulos
       FROM eleicoes e
       WHERE e.id = $1`,
      [req.params.eleicaoId]
    );

    if (report.rows.length === 0) return res.status(404).json({ message: 'Eleição não encontrada.' });

    const ranking = await query(
      `SELECT c.numero, c.nome, c.nome_urna, c.partido, c.cargo, c.ativo,
              COALESCE(SUM(v.quantidade), 0) AS votos
       FROM candidatos c
       LEFT JOIN votos v ON v.candidato_id = c.id
       LEFT JOIN apuracoes a ON a.id = v.apuracao_id AND a.eleicao_id = $1
       WHERE c.eleicao_id = $1
       GROUP BY c.id
       ORDER BY c.cargo, votos DESC, c.numero ASC`,
      [req.params.eleicaoId]
    );

    const escapeCsv = (value) => {
      let text = String(value ?? '');
      if (/^[\t\r ]*[=+@-]/.test(text)) text = `'${text}`;
      return `"${text.replace(/"/g, '""')}"`;
    };
    const summary = report.rows[0];
    const lines = [
      ['RELATORIO DE APURACAO'],
      ['Eleicao', summary.nome],
      ['Tipo', summary.tipo],
      ['Local', summary.local],
      ['Data', summary.data],
      ['Total de secoes', summary.total_secoes],
      ['Secoes apuradas', summary.apuradas],
      ['Eleitores aptos', summary.eleitores_aptos],
      ['Comparecimento', summary.comparecimento],
      ['Abstencoes', summary.abstencoes],
      ['Votos validos', summary.votos_validos],
      ['Votos brancos', summary.votos_brancos],
      ['Votos nulos', summary.votos_nulos],
      [],
      ['Numero', 'Nome', 'Nome de urna', 'Partido', 'Cargo', 'Ativo', 'Votos'],
      ...ranking.rows.map((candidate) => [
        candidate.numero,
        candidate.nome,
        candidate.nome_urna,
        candidate.partido,
        candidate.cargo,
        candidate.ativo ? 'Sim' : 'Nao',
        candidate.votos,
      ]),
    ];
    const csv = `\ufeff${lines.map((line) => line.map(escapeCsv).join(';')).join('\r\n')}`;
    const fileName = `relatorio-eleicao-${req.params.eleicaoId}.csv`;
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
    res.send(csv);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro ao exportar relatório.' });
  }
});

router.get('/:eleicaoId', async (req, res) => {
  try {
    const election = await query('SELECT * FROM eleicoes WHERE id = $1', [req.params.eleicaoId]);
    if (election.rows.length === 0) return res.status(404).json({ message: 'Eleição não encontrada.' });

    const totalSecoes = await query('SELECT COUNT(*) AS total FROM secoes WHERE eleicao_id = $1', [req.params.eleicaoId]);
    const secoesApuradas = await query("SELECT COUNT(*) AS total FROM apuracoes WHERE eleicao_id = $1 AND status = 'Conferida'", [req.params.eleicaoId]);
    const eleitores = await query('SELECT COALESCE(SUM(eleitores_aptos),0) AS total FROM secoes WHERE eleicao_id = $1', [req.params.eleicaoId]);
    const comparecimento = await query('SELECT COALESCE(SUM(comparecimento),0) AS total FROM apuracoes WHERE eleicao_id = $1', [req.params.eleicaoId]);
    const abstencoes = await query('SELECT COALESCE(SUM(abstencoes),0) AS total FROM apuracoes WHERE eleicao_id = $1', [req.params.eleicaoId]);
    const validos = await query('SELECT COALESCE(SUM(votos_validos),0) AS total FROM apuracoes WHERE eleicao_id = $1', [req.params.eleicaoId]);
    const brancos = await query('SELECT COALESCE(SUM(votos_brancos),0) AS total FROM apuracoes WHERE eleicao_id = $1', [req.params.eleicaoId]);
    const nulos = await query('SELECT COALESCE(SUM(votos_nulos),0) AS total FROM apuracoes WHERE eleicao_id = $1', [req.params.eleicaoId]);

    const total = Number(totalSecoes.rows[0].total || 0);
    const apuradas = Number(secoesApuradas.rows[0].total || 0);
    const summary = {
      total_secoes: total,
      secoes_apuradas: apuradas,
      secoes_pendentes: total - apuradas,
      percentual_apuracao: total > 0 ? Number(((apuradas / total) * 100).toFixed(2)) : 0,
      eleitores_aptos: Number(eleitores.rows[0].total || 0),
      comparecimento: Number(comparecimento.rows[0].total || 0),
      abstencoes: Number(abstencoes.rows[0].total || 0),
      votos_validos: Number(validos.rows[0].total || 0),
      votos_brancos: Number(brancos.rows[0].total || 0),
      votos_nulos: Number(nulos.rows[0].total || 0),
    };

    const ranking = await query(
      `SELECT c.id, c.numero, c.nome, c.partido, COALESCE(SUM(v.quantidade), 0) AS votos
       FROM candidatos c
       LEFT JOIN votos v ON v.candidato_id = c.id
       LEFT JOIN apuracoes a ON a.id = v.apuracao_id AND a.eleicao_id = $1
       WHERE c.eleicao_id = $1
       GROUP BY c.id, c.numero, c.nome, c.partido
       ORDER BY votos DESC, c.numero ASC`,
      [req.params.eleicaoId]
    );
    const totalVotos = ranking.rows.reduce((sum, row) => sum + Number(row.votos || 0), 0);

    res.json({
      eleicao: election.rows[0],
      summary,
      metrics: summary,
      ranking: ranking.rows.map((row, index) => ({
        posicao: index + 1,
        ...row,
        votos: Number(row.votos || 0),
        percentual: totalVotos > 0 ? Number(((Number(row.votos || 0) / totalVotos) * 100).toFixed(2)) : 0,
      })),
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro ao gerar relatório.' });
  }
});

module.exports = router;
