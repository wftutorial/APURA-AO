const express = require('express');
const router = express.Router();
const { query } = require('../db');
const { requireAuth, requireRole } = require('../auth');

router.use(requireAuth);

router.get('/', async (req, res) => {
  const { eleicao_id } = req.query;
  try {
    let sql = 'SELECT * FROM secoes';
    const params = [];
    if (eleicao_id) {
      sql += ' WHERE eleicao_id = $1';
      params.push(eleicao_id);
    }
    sql += " ORDER BY CASE WHEN numero ~ '^[0-9]+$' THEN numero::numeric END NULLS LAST, numero";
    const result = await query(sql, params);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao listar seções.' });
  }
});

router.post('/', requireRole('Administrador', 'Apurador'), async (req, res) => {
  const { eleicao_id, numero, urna, local, zona, municipio, eleitores_aptos, status = 'Aguardando' } = req.body || {};
  const identificadorSecao = String(numero ?? '').trim();

  if (!eleicao_id || !identificadorSecao || identificadorSecao.length > 100 || !urna || !local || !zona || !municipio || eleitores_aptos === undefined) {
    return res.status(400).json({ message: 'Todos os dados da seção são obrigatórios.' });
  }

  try {
    const result = await query(
      `INSERT INTO secoes (eleicao_id, numero, urna, local, zona, municipio, eleitores_aptos, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [eleicao_id, identificadorSecao, Number(urna), local, zona, municipio, Number(eleitores_aptos), status]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro ao cadastrar seção.' });
  }
});

router.put('/:id', requireRole('Administrador', 'Apurador'), async (req, res) => {
  const { numero, urna, local, zona, municipio, eleitores_aptos, status } = req.body || {};
  const identificadorSecao = numero !== undefined ? String(numero ?? '').trim() : null;
  if (identificadorSecao !== null && (!identificadorSecao || identificadorSecao.length > 100)) {
    return res.status(400).json({ message: 'Informe um número ou nome de seção com até 100 caracteres.' });
  }
  try {
    const result = await query(
      `UPDATE secoes SET numero = COALESCE($1, numero), urna = COALESCE($2, urna), local = COALESCE($3, local), zona = COALESCE($4, zona), municipio = COALESCE($5, municipio), eleitores_aptos = COALESCE($6, eleitores_aptos), status = COALESCE($7, status) WHERE id = $8 RETURNING *`,
      [identificadorSecao, urna !== undefined ? Number(urna) : null, local, zona, municipio, eleitores_aptos !== undefined ? Number(eleitores_aptos) : null, status, req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ message: 'Seção não encontrada.' });
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao atualizar seção.' });
  }
});

router.delete('/:id', requireRole('Administrador'), async (req, res) => {
  try {
    const result = await query('DELETE FROM secoes WHERE id = $1 RETURNING *', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ message: 'Seção não encontrada.' });
    res.json({ message: 'Seção removida com sucesso.' });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao excluir seção.' });
  }
});

module.exports = router;
