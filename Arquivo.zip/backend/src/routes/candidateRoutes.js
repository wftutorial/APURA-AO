const express = require('express');
const router = express.Router();
const { query } = require('../db');
const { requireAuth, requireRole } = require('../auth');

router.use(requireAuth);

router.get('/', async (req, res) => {
  const { eleicao_id } = req.query;
  try {
    let sql = 'SELECT * FROM candidatos';
    const params = [];
    if (eleicao_id) {
      sql += ' WHERE eleicao_id = $1';
      params.push(eleicao_id);
    }
    sql += ' ORDER BY numero';
    const result = await query(sql, params);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao listar candidatos.' });
  }
});

router.post('/', requireRole('Administrador', 'Apurador'), async (req, res) => {
  const { eleicao_id, numero, nome, nome_urna, partido, cargo, foto, ativo = true } = req.body || {};

  if (!eleicao_id || !numero || !nome || !nome_urna || !partido || !cargo) {
    return res.status(400).json({ message: 'Todos os campos principais do candidato são obrigatórios.' });
  }

  try {
    const result = await query(
      `INSERT INTO candidatos (eleicao_id, numero, nome, nome_urna, partido, cargo, foto, ativo)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [eleicao_id, numero, nome, nome_urna, partido, cargo, foto || null, ativo]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro ao cadastrar candidato.' });
  }
});

router.put('/:id', requireRole('Administrador', 'Apurador'), async (req, res) => {
  const { numero, nome, nome_urna, partido, cargo, foto, ativo } = req.body || {};
  try {
    const result = await query(
      `UPDATE candidatos SET numero = COALESCE($1, numero), nome = COALESCE($2, nome), nome_urna = COALESCE($3, nome_urna), partido = COALESCE($4, partido), cargo = COALESCE($5, cargo), foto = COALESCE($6, foto), ativo = COALESCE($7, ativo) WHERE id = $8 RETURNING *`,
      [numero, nome, nome_urna, partido, cargo, foto, ativo, req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ message: 'Candidato não encontrado.' });
    await query(
      `INSERT INTO logs (usuario_id, tabela, registro_id, acao, valor_anterior, valor_novo, ip, created_at)
       VALUES ($1, 'candidatos', $2, 'alteracao', $3, $4, $5, NOW())`,
      [req.user.id, req.params.id, JSON.stringify({ numero, nome, nome_urna, partido, cargo, foto, ativo }), JSON.stringify(result.rows[0]), req.ip]
    );
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao atualizar candidato.' });
  }
});

router.delete('/:id', requireRole('Administrador'), async (req, res) => {
  try {
    const result = await query('DELETE FROM candidatos WHERE id = $1 RETURNING *', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ message: 'Candidato não encontrado.' });
    await query(
      `INSERT INTO logs (usuario_id, tabela, registro_id, acao, valor_anterior, ip, created_at)
       VALUES ($1, 'candidatos', $2, 'exclusao', $3, $4, NOW())`,
      [req.user.id, req.params.id, JSON.stringify(result.rows[0]), req.ip]
    );
    res.json({ message: 'Candidato removido com sucesso.' });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao excluir candidato.' });
  }
});

module.exports = router;
