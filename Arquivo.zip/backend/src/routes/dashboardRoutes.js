const express = require('express');
const router = express.Router();
const { query } = require('../db');
const { requireAuth } = require('../auth');

router.use(requireAuth);

router.get('/summary/:eleicaoId', async (req, res) => {
  try {
    const election = await query('SELECT * FROM eleicoes WHERE id = $1', [req.params.eleicaoId]);
    if (election.rows.length === 0) return res.status(404).json({ message: 'Eleição não encontrada.' });

    const totalSecoes = await query('SELECT COUNT(*) AS total FROM secoes WHERE eleicao_id = $1', [req.params.eleicaoId]);
    const secoesApuradas = await query("SELECT COUNT(*) AS total FROM apuracoes WHERE eleicao_id = $1 AND status = 'Conferida'", [req.params.eleicaoId]);
    const secoesLancadas = await query('SELECT COUNT(*) AS total FROM apuracoes WHERE eleicao_id = $1', [req.params.eleicaoId]);
    const eleitores = await query('SELECT COALESCE(SUM(eleitores_aptos),0) AS total FROM secoes WHERE eleicao_id = $1', [req.params.eleicaoId]);
    const comparecimento = await query('SELECT COALESCE(SUM(comparecimento),0) AS total FROM apuracoes WHERE eleicao_id = $1', [req.params.eleicaoId]);
    const abstencoes = await query('SELECT COALESCE(SUM(abstencoes),0) AS total FROM apuracoes WHERE eleicao_id = $1', [req.params.eleicaoId]);
    const validos = await query('SELECT COALESCE(SUM(votos_validos),0) AS total FROM apuracoes WHERE eleicao_id = $1', [req.params.eleicaoId]);
    const brancos = await query('SELECT COALESCE(SUM(votos_brancos),0) AS total FROM apuracoes WHERE eleicao_id = $1', [req.params.eleicaoId]);
    const nulos = await query('SELECT COALESCE(SUM(votos_nulos),0) AS total FROM apuracoes WHERE eleicao_id = $1', [req.params.eleicaoId]);

    const total = Number(totalSecoes.rows[0].total || 0);
    const apuradas = Number(secoesApuradas.rows[0].total || 0);
    const lancadas = Number(secoesLancadas.rows[0].total || 0);

    res.json({
      eleicao: election.rows[0],
      metrics: {
        total_secoes: total,
        secoes_apuradas: apuradas,
        secoes_lancadas: lancadas,
        secoes_pendentes: total - lancadas,
        percentual_apuracao: total > 0 ? ((lancadas / total) * 100).toFixed(2) : 0,
        eleitores_aptos: Number(eleitores.rows[0].total || 0),
        comparecimento: Number(comparecimento.rows[0].total || 0),
        abstencoes: Number(abstencoes.rows[0].total || 0),
        votos_validos: Number(validos.rows[0].total || 0),
        votos_brancos: Number(brancos.rows[0].total || 0),
        votos_nulos: Number(nulos.rows[0].total || 0),
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro ao calcular resumo do painel.' });
  }
});

router.get('/ranking/:eleicaoId', async (req, res) => {
  try {
    const result = await query(
      `SELECT c.id, c.numero, c.nome, c.partido, c.cargo, COALESCE(SUM(v.quantidade), 0) AS votos
       FROM candidatos c
       LEFT JOIN votos v ON v.candidato_id = c.id
       LEFT JOIN apuracoes a ON a.id = v.apuracao_id AND a.eleicao_id = $1
       WHERE c.eleicao_id = $1
      GROUP BY c.id, c.numero, c.nome, c.partido, c.cargo
       ORDER BY votos DESC, c.numero ASC`,
      [req.params.eleicaoId]
    );

    const total = result.rows.reduce((sum, row) => sum + Number(row.votos || 0), 0);
    const ranking = result.rows.map((row, index) => ({
      posicao: index + 1,
      ...row,
      percentual: total > 0 ? ((Number(row.votos || 0) / total) * 100).toFixed(2) : 0,
      votos: Number(row.votos || 0),
    }));

    res.json(ranking);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro ao gerar ranking.' });
  }
});

module.exports = router;
