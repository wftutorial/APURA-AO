const KNOWN_FIELDS = new Set([
  'QRBU', 'VRQR', 'VRCH', 'ORIG', 'ORLC', 'PROC', 'DTPL', 'PLEI', 'TURN', 'FASE',
  'UNFE', 'MUNI', 'ZONA', 'SECA', 'AGRE', 'IDUE', 'IDCA', 'HASH', 'ASSI',
  'APTA', 'APTS', 'APTT', 'NOMI', 'LEGC', 'BRAN', 'NULO', 'TOTC',
]);

const FIELD_PATTERN = /(?:^|[\n;|])\s*([A-Z][A-Z0-9_]{2,12})\s*(?:=|:)\s*([^\n;|]*)/g;

function parseValue(value) {
  const trimmed = String(value ?? '').trim();
  if (/^-?\\d+$/.test(trimmed)) return Number(trimmed);
  return trimmed;
}

function parseFields(content) {
  const fields = {};
  const unknown = {};
  let match;
  while ((match = FIELD_PATTERN.exec(content)) !== null) {
    const key = match[1].toUpperCase();
    const value = parseValue(match[2]);
    if (KNOWN_FIELDS.has(key)) fields[key] = value;
    else unknown[key] = value;
  }
  return { fields, unknown };
}

function integer(fields, key) {
  const value = Number(fields[key]);
  return Number.isInteger(value) ? value : null;
}

function parse(content) {
  const raw = String(content ?? '');
  const { fields, unknown } = parseFields(raw);
  const aptos = integer(fields, 'APTA') ?? integer(fields, 'APTS') ?? integer(fields, 'APTT');
  const comparecimento = integer(fields, 'TOTC');
  const parsed = {
    processo_eleitoral: fields.PROC ?? null,
    data_pleito: fields.DTPL ?? null,
    turno: integer(fields, 'TURN'),
    fase: fields.FASE ?? null,
    uf: fields.UNFE ?? null,
    municipio: fields.MUNI ?? null,
    zona: fields.ZONA != null ? String(fields.ZONA) : null,
    secao: fields.SECA != null ? String(fields.SECA) : null,
    agregacao: fields.AGRE ?? null,
    id_urna: fields.IDUE ?? null,
    id_carga: fields.IDCA ?? null,
    versao: fields.VRQR ?? fields.VRCH ?? null,
    eleitores_aptos: aptos,
    comparecimento,
    faltosos: aptos !== null && comparecimento !== null ? Math.max(aptos - comparecimento, 0) : null,
    votos_nominais: integer(fields, 'NOMI'),
    votos_legenda: integer(fields, 'LEGC'),
    votos_brancos: integer(fields, 'BRAN'),
    votos_nulos: integer(fields, 'NULO'),
    total_votos: comparecimento,
    hash_original: fields.HASH != null ? String(fields.HASH) : null,
    assinatura: fields.ASSI != null ? String(fields.ASSI) : null,
    fields,
    unknown_fields: unknown,
    raw,
  };
  return parsed;
}

module.exports = { parse, KNOWN_FIELDS };
