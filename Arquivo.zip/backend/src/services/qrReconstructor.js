const crypto = require('crypto');

function normalizeQr(item, position) {
  const content = String(item?.content ?? item?.conteudo ?? item?.raw ?? item ?? '').trim();
  const match = content.match(/(?:QR\s*)?(\d+)\s*\/\s*(\d+)/i);
  const index = Number(item?.index ?? item?.indice ?? match?.[1] ?? position + 1);
  const total = Number(item?.total ?? item?.quantidade_total ?? match?.[2] ?? 0) || null;
  return { index, total, content };
}

function reconstruct(input) {
  const items = (Array.isArray(input) ? input : [input]).map(normalizeQr).filter((item) => item.content);
  const ordered = items.sort((left, right) => left.index - right.index);
  const total = ordered.reduce((value, item) => Math.max(value, item.total || 0), 0) || null;
  const indexes = new Set(ordered.map((item) => item.index));
  const complete = total ? ordered.length === total && [...Array(total)].every((_, index) => indexes.has(index + 1)) : ordered.length > 0;
  const content = ordered.map((item) => item.content.replace(/^QR\s*\d+\s*\/\s*\d+\s*[:;|]?\s*/i, '')).join('');

  return {
    items: ordered,
    total,
    received: ordered.length,
    missing: total ? [...Array(total)].map((_, index) => index + 1).filter((index) => !indexes.has(index)) : [],
    complete,
    content,
    fingerprint: crypto.createHash('sha512').update(content).digest('hex'),
  };
}

module.exports = { reconstruct };
