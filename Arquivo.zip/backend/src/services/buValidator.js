const crypto = require('crypto');

function validateHash(parsed) {
  if (!parsed.hash_original) {
    return { status: 'NÃO INFORMADO', calculated: null, details: 'Campo HASH ausente.' };
  }
  return {
    status: 'REQUIRES CONFIGURATION / DOCUMENTATION',
    calculated: crypto.createHash('sha512').update(parsed.raw).digest('hex'),
    details: 'O algoritmo e o trecho canônico do BU não foram fornecidos na documentação disponível.',
  };
}

function validateSignature(parsed) {
  return {
    status: parsed.assinatura ? 'REQUIRES CONFIGURATION / DOCUMENTATION' : 'NÃO INFORMADO',
    details: 'A chave pública e os parâmetros Ed25519/EdDSA do pleito são necessários para validar ASSI.',
  };
}

function validate(parsed, reconstruction) {
  const hash = validateHash(parsed);
  const signature = validateSignature(parsed);
  const errors = [];
  if (!reconstruction.complete) errors.push('BU incompleto: faltam QR Codes.');
  if (!parsed.municipio) errors.push('Município não identificado.');
  if (!parsed.zona) errors.push('Zona não identificada.');
  if (!parsed.secao) errors.push('Seção não identificada.');
  const status = errors.length ? 'PENDENTE' : 'PROCESSANDO';
  return { status, hash, signature, errors };
}

module.exports = { validate, validateHash, validateSignature };
