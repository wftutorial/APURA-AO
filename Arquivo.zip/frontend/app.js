const API_URL = `${window.location.origin}/api`;

function readStoredUser() {
  try {
    return JSON.parse(localStorage.getItem('user') || 'null');
  } catch {
    localStorage.removeItem('user');
    return null;
  }
}

const state = {
  token: localStorage.getItem('token') || '',
  user: readStoredUser(),
  activeView: 'dashboard',
  elections: [],
  candidates: [],
  sections: [],
  apuracoes: [],
  ranking: [],
  summary: null,
  report: null,
  audit: [],
  selectedElectionId: null,
  dashboardAutoRefresh: false,
};

const app = document.getElementById('app');
let dashboardRefreshTimer = null;

function clearSession() {
  if (dashboardRefreshTimer) window.clearInterval(dashboardRefreshTimer);
  dashboardRefreshTimer = null;
  state.token = '';
  state.user = null;
  state.activeView = 'dashboard';
  localStorage.removeItem('token');
  localStorage.removeItem('user');
}

function formatCurrency(value) {
  return Number(value || 0).toLocaleString('pt-BR');
}

function formatPercent(value) {
  return `${Number(value || 0).toFixed(2).replace('.', ',')}%`;
}

async function removeResource(path, label, rerender = render) {
  if (!window.confirm(`Excluir ${label}? Esta ação não pode ser desfeita.`)) return;
  try {
    await apiFetch(path, { method: 'DELETE' });
    await loadAppData();
    rerender();
  } catch (error) {
    alert(error.message);
  }
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  }[char]));
}

async function apiFetch(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (state.token) {
    headers.Authorization = `Bearer ${state.token}`;
  }

  const response = await fetch(`${API_URL}${path}`, { ...options, headers });
  const payload = await response.json().catch(() => ({}));

  if (!response.ok) {
    if (response.status === 401 && state.token) {
      clearSession();
      renderLogin();
    }
    throw new Error(payload.message || 'Erro na operação');
  }

  return payload;
}

async function login(email, senha) {
  const data = await apiFetch('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, senha })
  });

  state.token = data.token;
  state.user = data.user;
  localStorage.setItem('token', data.token);
  localStorage.setItem('user', JSON.stringify(data.user));
  state.activeView = 'dashboard';
  await loadAppData();
  render();
}

async function loadAppData() {
  try {
    const elections = await apiFetch('/elections');
    state.elections = elections || [];

    if (state.selectedElectionId == null && elections.length > 0) {
      state.selectedElectionId = Number(elections[0].id);
    }

    if (!state.selectedElectionId && elections.length > 0) {
      state.selectedElectionId = Number(elections[0].id);
    }

    if (state.selectedElectionId) {
      state.candidates = await apiFetch(`/candidates?eleicao_id=${state.selectedElectionId}`);
      state.sections = await apiFetch(`/sections?eleicao_id=${state.selectedElectionId}`);
      state.apuracoes = await apiFetch(`/apuracao/by-election/${state.selectedElectionId}`);
      state.summary = await apiFetch(`/dashboard/summary/${state.selectedElectionId}`);
      state.ranking = await apiFetch(`/dashboard/ranking/${state.selectedElectionId}`);
      state.report = await apiFetch(`/reports/${state.selectedElectionId}`);
    } else {
      state.candidates = [];
      state.sections = [];
      state.apuracoes = [];
      state.summary = null;
      state.ranking = [];
      state.report = null;
    }

    if (state.user?.perfil === 'Administrador') {
      state.audit = await apiFetch('/audit');
    }
  } catch (error) {
    console.error(error);
    throw error;
  }
}

function renderLogin() {
  app.innerHTML = `
    <div class="app-shell">
      <div class="login-box">
        <h1>APURAÇÃO DE VOTOS</h1>
        <p>Controle de eleição, apuração, conferência e relatórios.</p>
        <form id="login-form">
          <div class="form-grid">
            <label>
              E-mail/usuário
              <input type="email" name="email" autocomplete="username" required />
            </label>
            <label>
              Senha
              <input type="password" name="senha" autocomplete="current-password" required />
            </label>
          </div>
          <div style="margin-top:18px; display:flex; gap:10px; flex-wrap:wrap;">
            <button class="primary" type="submit">Entrar</button>
            <button class="secondary" type="button" id="forgot-btn">Recuperar senha</button>
          </div>
        </form>
      </div>
    </div>
  `;

  document.getElementById('login-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const email = String(form.get('email') || '').trim();
    const senha = String(form.get('senha') || '');

    try {
      await login(email, senha);
    } catch (error) {
      alert(error.message);
    }
  });

  document.getElementById('forgot-btn').addEventListener('click', () => {
    alert('Recuperação de senha: encaminhar e-mail para o administrador do sistema.');
  });
}

function renderShell() {
  app.innerHTML = `
    <div class="topbar">
      <div class="brand-lockup">
        <span class="brand-mark" aria-hidden="true">AV</span>
        <div><strong>Apuração</strong><small>Gestão eleitoral</small></div>
      </div>
      <label class="topbar-election">
        <span>Eleição ativa</span>
        <select id="election-selector">
          ${state.elections.map((election) => `
            <option value="${election.id}" ${Number(election.id) === Number(state.selectedElectionId) ? 'selected' : ''}>${escapeHtml(election.nome)}</option>
          `).join('') || '<option value="">Nenhuma eleição</option>'}
        </select>
      </label>
      <div class="topbar-actions">
        <div class="user-chip"><span class="user-avatar">${escapeHtml((state.user?.nome || 'A').trim().charAt(0).toUpperCase())}</span><span><strong>${escapeHtml(state.user?.nome || 'Administrador')}</strong><small>${escapeHtml(state.user?.perfil || 'Usuário')}</small></span></div>
        <button class="secondary logout-btn" id="logout-btn">Sair</button>
      </div>
    </div>

    <div class="dashboard">
      <nav class="nav-tabs" aria-label="Navegação principal">
        <span class="nav-caption">MENU PRINCIPAL</span>
        <button class="tab-btn ${state.activeView === 'dashboard' ? 'primary' : 'secondary'}" data-view="dashboard">Visão geral</button>
        <button class="tab-btn ${state.activeView === 'eleicoes' ? 'primary' : 'secondary'}" data-view="eleicoes">Eleições</button>
        <button class="tab-btn ${state.activeView === 'candidatos' ? 'primary' : 'secondary'}" data-view="candidatos">Candidatos</button>
        <button class="tab-btn ${state.activeView === 'secoes' ? 'primary' : 'secondary'}" data-view="secoes">Seções eleitorais</button>
        <button class="tab-btn ${state.activeView === 'apuracao' ? 'primary' : 'secondary'}" data-view="apuracao">Lançamento manual</button>
        <span class="nav-caption nav-caption-secondary">DADOS E CONTROLE</span>
        <button class="tab-btn ${state.activeView === 'relatorios' ? 'primary' : 'secondary'}" data-view="relatorios">Relatórios</button>
        <button class="tab-btn ${state.activeView === 'importacao' ? 'primary' : 'secondary'}" data-view="importacao">Importação</button>
        ${state.user?.perfil === 'Administrador' ? `<button class="tab-btn ${state.activeView === 'audit' ? 'primary' : 'secondary'}" data-view="audit">Auditoria</button>` : ''}
      </div>
      <main id="content-panel" class="content-panel"></main>
    </div>
  `;

  const electionSelector = document.getElementById('election-selector');
  if (electionSelector) {
    electionSelector.addEventListener('change', async (event) => {
      const value = Number(event.target.value);
      state.selectedElectionId = value || null;
      await loadAppData();
      render();
    });
  }

  document.getElementById('logout-btn').addEventListener('click', () => {
    clearSession();
    render();
  });

  document.querySelectorAll('.tab-btn').forEach((button) => {
    button.addEventListener('click', () => {
      state.activeView = button.dataset.view;
      window.scrollTo(0, 0);
      render();
    });
  });
}

function renderDashboardView() {
  const panel = document.getElementById('content-panel');
  if (!state.summary || !state.summary.metrics) {
    panel.innerHTML = '<div class="panel"><p>Selecione ou cadastre uma eleição para exibir o painel.</p></div>';
    return;
  }

  const metrics = state.summary.metrics;
  const totalEleitores = Number(metrics.eleitores_aptos || 0);
  const comparecimentoPercent = totalEleitores > 0 ? (Number(metrics.comparecimento || 0) / totalEleitores) * 100 : 0;
  const apuracaoPercent = Number(metrics.percentual_apuracao || 0);

  panel.innerHTML = `
    <div class="panel card" style="padding:18px; margin-bottom:20px;">
      <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap;">
        <div><h2 style="margin-bottom:6px;">Acompanhamento da eleição</h2><p style="margin:0; color:var(--muted);">${escapeHtml(state.summary.eleicao?.nome || 'Eleição selecionada')}</p></div>
        <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
          <label style="display:flex; flex-direction:row; align-items:center; gap:8px;"><input id="dashboard-auto-refresh" type="checkbox" ${state.dashboardAutoRefresh ? 'checked' : ''} /> Atualizar automaticamente</label>
          <button class="secondary" type="button" id="dashboard-refresh">Atualizar agora</button>
        </div>
      </div>
      <div style="margin-top:16px; display:flex; justify-content:space-between; gap:10px;"><strong>Lançamento das seções</strong><span id="dashboard-last-update">Atualizado agora</span></div>
      <div class="progress" style="height:14px; margin-top:8px;"><span style="width:${Math.min(apuracaoPercent, 100)}%"></span></div>
      <div style="display:flex; justify-content:space-between; margin-top:6px; color:var(--muted);"><span>${formatPercent(apuracaoPercent)} lançada</span><span>${formatCurrency(metrics.secoes_lancadas ?? metrics.secoes_apuradas)} de ${formatCurrency(metrics.total_secoes)} seções</span></div>
    </div>

    <div class="grid grid-4">
      <div class="stat-card">
        <h3>Seções</h3>
        <div class="big">${formatCurrency(metrics.total_secoes)}</div>
        <small>${formatCurrency(metrics.secoes_pendentes)} pendentes</small>
      </div>
      <div class="stat-card">
        <h3>Lançadas</h3>
        <div class="big">${formatCurrency(metrics.secoes_lancadas ?? metrics.secoes_apuradas)}</div>
        <small>${formatCurrency(metrics.secoes_apuradas)} conferidas</small>
      </div>
      <div class="stat-card">
        <h3>Comparecimento</h3>
        <div class="big">${formatPercent(comparecimentoPercent)}</div>
        <small>${formatCurrency(metrics.comparecimento)} eleitores</small>
      </div>
      <div class="stat-card">
        <h3>Votos válidos</h3>
        <div class="big">${formatCurrency(metrics.votos_validos)}</div>
        <small>${formatCurrency(metrics.votos_brancos)} brancos · ${formatCurrency(metrics.votos_nulos)} nulos</small>
      </div>
    </div>

    <div class="grid grid-2" style="margin-top:24px;">
      ${[
        ['governo', 'Governo', '#0f766e', '#ccfbf1'],
        ['deputado-federal', 'Deputado Federal', '#1d4ed8', '#dbeafe'],
        ['deputado-estadual', 'Deputado Estadual', '#7c3aed', '#ede9fe'],
        ['senado', 'Senado', '#b45309', '#fef3c7'],
      ].map(([key, title, color, soft]) => `
        <section class="panel card" style="padding:18px; border-top:6px solid ${color};">
          <div style="display:flex; justify-content:space-between; align-items:center; gap:10px; margin-bottom:14px;">
            <h3 style="margin:0; color:${color};">${title}</h3><span id="dashboard-count-${key}" style="background:${soft}; color:${color}; padding:5px 9px; border-radius:999px; font-weight:700;">0</span>
          </div>
          <div class="form-grid" style="margin-bottom:14px;">
            <label>Pesquisar<input id="dashboard-search-${key}" data-category="${key}" type="search" placeholder="Nome, número ou partido" /></label>
            <label>Limite<select id="dashboard-limit-${key}" data-category="${key}"><option value="5">5</option><option value="10">10</option><option value="20">20</option><option value="0">Todos</option></select></label>
          </div>
          <div class="table-wrap"><table><thead><tr><th>Pos.</th><th>Candidato</th><th>Votos</th><th>%</th></tr></thead><tbody id="dashboard-ranking-${key}"></tbody></table></div>
          ${key === 'governo' ? `<div style="margin-top:12px; padding:10px; background:#f0fdfa; border-radius:8px;"><strong>Vice-Governador</strong><div>${state.candidates.filter((candidate) => String(candidate.cargo || '').toLowerCase().includes('vice') && String(candidate.cargo || '').toLowerCase().includes('govern')).map((candidate) => escapeHtml(candidate.nome)).join(', ') || 'Não cadastrado'}</div><small>Sem votação separada</small></div>` : ''}
        </section>
      `).join('')}
    </div>

    <div style="margin-top:24px;" class="table-wrap">
      <table>
        <tbody>
          <tr><td>Votos válidos</td><td>${formatCurrency(metrics.votos_validos)}</td></tr>
          <tr><td>Brancos</td><td>${formatCurrency(metrics.votos_brancos)}</td></tr>
          <tr><td>Nulos</td><td>${formatCurrency(metrics.votos_nulos)}</td></tr>
          <tr><td>Abstenções</td><td>${formatCurrency(metrics.abstencoes)}</td></tr>
          <tr><td>Comparecimento</td><td>${formatCurrency(metrics.comparecimento)}</td></tr>
        </tbody>
      </table>
    </div>
  `;

  const categoryMatches = {
    governo: (cargo) => cargo.includes('govern') && !cargo.includes('vice'),
    'deputado-federal': (cargo) => cargo.includes('deputado') && cargo.includes('federal'),
    'deputado-estadual': (cargo) => cargo.includes('deputado') && cargo.includes('estadual'),
    senado: (cargo) => cargo.includes('senad'),
  };
  const renderRankings = () => Object.entries(categoryMatches).forEach(([key, matches]) => {
    const searchInput = document.getElementById(`dashboard-search-${key}`);
    const limitInput = document.getElementById(`dashboard-limit-${key}`);
    const rankingBody = document.getElementById(`dashboard-ranking-${key}`);
    const searchTerm = String(searchInput.value || '').trim().toLowerCase();
    const rows = (state.ranking || []).filter((row) => {
      const cargo = String(row.cargo || '').toLowerCase();
      return matches(cargo) && [row.numero, row.nome, row.partido].join(' ').toLowerCase().includes(searchTerm);
    });
    const limit = Number(limitInput.value || 5);
    const visibleRows = limit === 0 ? rows : rows.slice(0, limit);
    document.getElementById(`dashboard-count-${key}`).textContent = `${visibleRows.length}/${rows.length}`;
    rankingBody.innerHTML = visibleRows.map((row, index) => `
      <tr><td>${index + 1}</td><td><strong>${escapeHtml(row.numero)} · ${escapeHtml(row.nome)}</strong></td><td>${formatCurrency(row.votos)}</td><td>${formatPercent(row.percentual)}</td></tr>
    `).join('') || '<tr><td colspan="4">Nenhum resultado para este cargo.</td></tr>';
  });
  Object.keys(categoryMatches).forEach((key) => {
    document.getElementById(`dashboard-search-${key}`).addEventListener('input', renderRankings);
    document.getElementById(`dashboard-limit-${key}`).addEventListener('change', renderRankings);
  });
  renderRankings();

  const refreshButton = document.getElementById('dashboard-refresh');
  const autoRefresh = document.getElementById('dashboard-auto-refresh');
  const refreshDashboard = async () => {
    refreshButton.disabled = true;
    try {
      await loadAppData();
      renderActiveView();
    } catch (error) { alert(error.message); }
    finally { refreshButton.disabled = false; }
  };
  refreshButton.addEventListener('click', refreshDashboard);
  autoRefresh.addEventListener('change', () => {
    state.dashboardAutoRefresh = autoRefresh.checked;
    if (dashboardRefreshTimer) window.clearInterval(dashboardRefreshTimer);
    dashboardRefreshTimer = autoRefresh.checked ? window.setInterval(refreshDashboard, 30000) : null;
  });
  if (dashboardRefreshTimer) window.clearInterval(dashboardRefreshTimer);
  dashboardRefreshTimer = state.dashboardAutoRefresh ? window.setInterval(refreshDashboard, 30000) : null;
}

async function createElection(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const payload = {
    nome: String(form.get('nome') || '').trim(),
    tipo: String(form.get('tipo') || '').trim(),
    data: form.get('data'),
    local: String(form.get('local') || '').trim(),
    quantidade_secoes: Number(form.get('quantidade_secoes') || 0),
    quantidade_urnas: Number(form.get('quantidade_urnas') || 0),
    status: form.get('status') || 'Não iniciada',
  };

  try {
    const electionId = form.get('id');
    await apiFetch(electionId ? `/elections/${electionId}` : '/elections', {
      method: electionId ? 'PUT' : 'POST',
      body: JSON.stringify(payload)
    });
    await loadAppData();
    render();
  } catch (error) {
    alert(error.message);
  }
}

function renderReportsView() {
  const panel = document.getElementById('content-panel');
  const reportData = state.report || {};
  const summary = reportData.summary || state.summary?.metrics || {};
  const ranking = reportData.ranking || state.ranking || [];

  const rows = ranking.slice(0, 10).map((row, index) => `
    <tr>
      <td>${index + 1}</td>
      <td>${escapeHtml(row.numero)}</td>
      <td>${escapeHtml(row.nome)}</td>
      <td>${formatCurrency(row.votos)}</td>
      <td>${formatPercent(row.percentual)}</td>
    </tr>
  `).join('');

  panel.innerHTML = `
    <div class="grid">
      <div class="panel card" style="padding:18px;">
        <h3>Resumo geral</h3>
        <table>
          <tbody>
            <tr><td>Seções</td><td>${formatCurrency(summary.total_secoes)}</td></tr>
            <tr><td>Seções apuradas</td><td>${formatCurrency(summary.secoes_apuradas)}</td></tr>
            <tr><td>Pendente</td><td>${formatCurrency(summary.secoes_pendentes)}</td></tr>
            <tr><td>Percentual</td><td>${formatPercent(summary.percentual_apuracao)}</td></tr>
            <tr><td>Eleitores aptos</td><td>${formatCurrency(summary.eleitores_aptos)}</td></tr>
            <tr><td>Comparecimento</td><td>${formatCurrency(summary.comparecimento)}</td></tr>
          </tbody>
        </table>
      </div>

      <div class="panel card" style="padding:18px;">
        <h3>Votações</h3>
        <table>
          <tbody>
            <tr><td>Válidos</td><td>${formatCurrency(summary.votos_validos)}</td></tr>
            <tr><td>Brancos</td><td>${formatCurrency(summary.votos_brancos)}</td></tr>
            <tr><td>Nulos</td><td>${formatCurrency(summary.votos_nulos)}</td></tr>
            <tr><td>Abstenções</td><td>${formatCurrency(summary.abstencoes)}</td></tr>
          </tbody>
        </table>
        <div style="margin-top:16px;">
          <button class="primary" id="export-report-btn">Exportar relatório</button>
        </div>
      </div>
    </div>

    <div class="panel card" style="padding:18px; margin-top:20px;">
      <h3>Ranking final</h3>
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Posição</th><th>Número</th><th>Nome</th><th>Votos</th><th>%</th></tr>
          </thead>
          <tbody>${rows || '<tr><td colspan="6">Sem dados disponíveis.</td></tr>'}</tbody>
        </table>
      </div>
    </div>
  `;

  const exportButton = document.getElementById('export-report-btn');
  if (exportButton) {
    exportButton.addEventListener('click', async () => {
      if (!state.selectedElectionId) {
        alert('Selecione uma eleição antes de exportar.');
        return;
      }

      exportButton.disabled = true;
      exportButton.textContent = 'Gerando arquivo...';
      try {
        const response = await fetch(`${API_URL}/reports/export/${state.selectedElectionId}`, {
          headers: { Authorization: `Bearer ${state.token}` },
        });
        if (!response.ok) {
          const payload = await response.json().catch(() => ({}));
          throw new Error(payload.message || 'Não foi possível exportar o relatório.');
        }

        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `relatorio-eleicao-${state.selectedElectionId}.csv`;
        link.style.display = 'none';
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      } catch (error) {
        alert(error.message);
      } finally {
        exportButton.disabled = false;
        exportButton.textContent = 'Exportar relatório';
      }
    });
  }
}

function renderImportView() {
  const panel = document.getElementById('content-panel');
  panel.innerHTML = `
    <div class="panel card" style="padding:18px;">
      <h3>Importação de dados</h3>
      <form id="import-form">
        <label>
          Arquivo CSV ou Excel
          <input type="file" name="file" accept=".csv,.xlsx,.xls" required />
        </label>
        <div style="margin-top:16px;">
          <button class="primary" type="submit">Pré-visualizar</button>
        </div>
      </form>
      <div id="import-preview" style="margin-top:18px;"></div>
    </div>
  `;

  document.getElementById('import-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const file = formData.get('file');

    if (!file || !file.name) {
      alert('Selecione um arquivo antes de importar.');
      return;
    }

    const previewBox = document.getElementById('import-preview');

    try {
      const response = await fetch(`${API_URL}/import/preview`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${state.token}` },
        body: formData,
      });

      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.message || 'Erro ao importar arquivo.');

      const previewRows = (payload.preview || []).slice(0, 5).map((row) => `
        <tr>${Object.entries(row).map(([key, value]) => `<td>${escapeHtml(String(value ?? ''))}</td>`).join('')}</tr>
      `).join('');

      const columns = Object.keys(payload.preview?.[0] || {});

      previewBox.innerHTML = `
        <p><strong>Total:</strong> ${payload.total || 0}</p>
        <div class="table-wrap">
          <table>
            <thead><tr>${columns.map((column) => `<th>${escapeHtml(column)}</th>`).join('')}</tr></thead>
            <tbody>${previewRows || '<tr><td colspan="1">Sem prévia.</td></tr>'}</tbody>
          </table>
        </div>
      `;
    } catch (error) {
      previewBox.innerHTML = `<p style="color:red;">${escapeHtml(error.message)}</p>`;
    }
  });
}

function renderElectionsView() {
  const panel = document.getElementById('content-panel');
  panel.innerHTML = `
    <div class="grid grid-2">
      <div class="panel card" style="padding:18px;">
          <h3 id="election-form-title">Cadastro de eleição</h3>
        <form id="election-form" class="form-grid">
          <input type="hidden" name="id" />
          <label>Nome<input name="nome" required /></label>
          <label>Tipo<select name="tipo"><option>Municipal</option><option>Estadual</option><option>Federal</option><option>Prefeitura</option></select></label>
          <label>Data<input name="data" type="date" required /></label>
          <label>Local<input name="local" required /></label>
          <label>Seções<input name="quantidade_secoes" type="number" min="0" value="0" /></label>
          <label>Urnas<input name="quantidade_urnas" type="number" min="0" value="0" /></label>
          <label>Status<select name="status"><option>Não iniciada</option><option>Em andamento</option><option>Encerrada</option></select></label>
          <div style="grid-column:1 / -1;"><button class="primary" type="submit">Salvar eleição</button></div>
        </form>
      </div>

      <div class="panel card" style="padding:18px;">
        <h3>Eleições cadastradas</h3>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Nome</th><th>Tipo</th><th>Status</th><th>Ações</th></tr></thead>
            <tbody>
              ${state.elections.map((item) => `
                <tr>
                  <td>${escapeHtml(item.nome)}</td>
                  <td>${escapeHtml(item.tipo)}</td>
                  <td>${escapeHtml(item.status)}</td>
                  <td><button type="button" class="secondary edit-election" data-id="${item.id}">Editar</button> <button type="button" class="danger delete-election" data-id="${item.id}">Excluir</button></td>
                </tr>
              `).join('') || '<tr><td colspan="3">Nenhuma eleição cadastrada.</td></tr>'}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;

  document.getElementById('election-form').addEventListener('submit', createElection);
  document.querySelectorAll('.edit-election').forEach((button) => button.addEventListener('click', () => {
    const item = state.elections.find((election) => String(election.id) === button.dataset.id);
    const form = document.getElementById('election-form');
    Object.entries(item || {}).forEach(([key, value]) => { if (form.elements[key]) form.elements[key].value = value ?? ''; });
    document.getElementById('election-form-title').textContent = 'Alterar eleição';
  }));
  document.querySelectorAll('.delete-election').forEach((button) => button.addEventListener('click', () => removeResource(`/elections/${button.dataset.id}`, 'a eleição')));
}

async function createCandidate(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const payload = {
    eleicao_id: Number(state.selectedElectionId),
    numero: String(form.get('numero') || '').trim(),
    nome: String(form.get('nome') || '').trim(),
    nome_urna: String(form.get('nome_urna') || '').trim(),
    partido: String(form.get('partido') || '').trim(),
    cargo: String(form.get('cargo') || '').trim(),
    foto: form.get('foto') || '',
    ativo: form.get('ativo') === 'true',
  };

  try {
    const candidateId = form.get('id');
    await apiFetch(candidateId ? `/candidates/${candidateId}` : '/candidates', { method: candidateId ? 'PUT' : 'POST', body: JSON.stringify(payload) });
    await loadAppData();
    render();
  } catch (error) {
    alert(error.message);
  }
}

function renderCandidatesView() {
  const panel = document.getElementById('content-panel');
  const selectedElection = state.elections.find((election) => Number(election.id) === Number(state.selectedElectionId));
  panel.innerHTML = `
    <div class="grid">
      <div class="panel card" style="padding:18px;">
        <h3 id="candidate-form-title">Cadastro de candidatos</h3>
        <form id="candidate-form" class="form-grid">
          <input type="hidden" name="id" />
          <label>Número<input name="numero" type="number" required /></label>
          <label>Nome completo<input name="nome" required /></label>
          <label>Nome de urna<input name="nome_urna" required /></label>
          <label>Partido<input name="partido" required /></label>
          <label>Cargo<input name="cargo" required /></label>
          <label>Foto<input name="foto" type="text" /></label>
          <label>Status<select name="ativo"><option value="true">Ativo</option><option value="false">Inativo</option></select></label>
          <div style="grid-column:1 / -1; display:flex; gap:10px; flex-wrap:wrap;"><button class="primary" type="submit">Salvar candidato</button><button class="secondary" type="button" id="cancel-candidate-edit" hidden>Cancelar edição</button></div>
        </form>
      </div>

      <div class="panel card" style="padding:18px;">
        <h3>Candidatos da eleição</h3>
        <p>${escapeHtml(selectedElection?.nome || 'Eleição não selecionada')} · <strong>${state.candidates.length}</strong> candidatos carregados</p>
        <div class="form-grid" style="margin-bottom:16px;">
          <label>Buscar candidato
            <input id="candidate-search" type="search" placeholder="Nome, número, partido ou cargo" />
          </label>
          <label>Filtrar por cargo
            <select id="candidate-office-filter">
              <option value="">Todos os cargos</option>
              ${[...new Set(state.candidates.map((item) => item.cargo).filter(Boolean))].sort().map((cargo) => `<option value="${escapeHtml(cargo)}">${escapeHtml(cargo)}</option>`).join('')}
            </select>
          </label>
        </div>
        <div id="candidate-boards" class="grid grid-2"></div>
      </div>
    </div>
  `;

  document.getElementById('candidate-form').addEventListener('submit', createCandidate);
  document.getElementById('cancel-candidate-edit').addEventListener('click', () => {
    document.getElementById('candidate-form').reset();
    document.querySelector('#candidate-form [name="id"]').value = '';
    document.getElementById('candidate-form-title').textContent = 'Cadastro de candidatos';
    document.getElementById('cancel-candidate-edit').hidden = true;
  });

  const boardsContainer = document.getElementById('candidate-boards');
  const searchInput = document.getElementById('candidate-search');
  const officeFilter = document.getElementById('candidate-office-filter');
  const boardFilters = {};

  function renderCandidateRows() {
    const searchTerm = String(searchInput.value || '').trim().toLowerCase();
    const selectedOffice = String(officeFilter.value || '');
    const filteredCandidates = state.candidates.filter((candidate) => {
      const searchableText = [candidate.numero, candidate.nome, candidate.nome_urna, candidate.partido, candidate.cargo].join(' ').toLowerCase();
      return (!searchTerm || searchableText.includes(searchTerm)) && (!selectedOffice || candidate.cargo === selectedOffice);
    });

    const categoryOrder = ['Governo', 'Vice-Governador', 'Deputado Estadual', 'Deputado Federal', 'Senado'];
    const categoryFor = (candidate) => {
      const cargo = String(candidate.cargo || '').toLowerCase();
      if (cargo.includes('vice') && cargo.includes('govern')) return 'Vice-Governador';
      if (cargo.includes('govern')) return 'Governo';
      if (cargo.includes('deputado') && cargo.includes('estadual')) return 'Deputado Estadual';
      if (cargo.includes('deputado') && cargo.includes('federal')) return 'Deputado Federal';
      if (cargo.includes('senad')) return 'Senado';
      return candidate.cargo || 'Outros cargos';
    };
    const groupedCandidates = filteredCandidates.reduce((groups, candidate) => {
      const category = categoryFor(candidate);
      if (!groups[category]) groups[category] = [];
      groups[category].push(candidate);
      return groups;
    }, {});
    const categories = Object.keys(groupedCandidates).sort((left, right) => {
      const leftIndex = categoryOrder.indexOf(left);
      const rightIndex = categoryOrder.indexOf(right);
      return (leftIndex === -1 ? categoryOrder.length : leftIndex) - (rightIndex === -1 ? categoryOrder.length : rightIndex) || left.localeCompare(right);
    });

    boardsContainer.innerHTML = categories.map((category) => {
      const filter = boardFilters[category] || { search: '', limit: 10 };
      const boardSearch = filter.search.toLowerCase();
      const candidates = groupedCandidates[category]
        .filter((candidate) => [candidate.numero, candidate.nome, candidate.nome_urna, candidate.partido].join(' ').toLowerCase().includes(boardSearch))
        .sort((left, right) => Number(left.numero || 0) - Number(right.numero || 0));
      const visibleCandidates = filter.limit === 0 ? candidates : candidates.slice(0, filter.limit);
      return `
        <section class="panel card" style="padding:16px;">
          <div style="display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap; margin-bottom:12px;">
            <h3 style="margin:0;">${escapeHtml(category).toUpperCase()}</h3>
            <span>${visibleCandidates.length}/${candidates.length}</span>
          </div>
          <div class="form-grid" style="margin-bottom:12px;">
            <label>Pesquisar neste quadro
              <input class="candidate-board-search" data-category="${escapeHtml(category)}" type="search" value="${escapeHtml(filter.search)}" placeholder="Nome, número ou partido" />
            </label>
            <label>Limite neste quadro
              <select class="candidate-board-limit" data-category="${escapeHtml(category)}">
                ${[5, 10, 20, 50, 0].map((limit) => `<option value="${limit}" ${Number(filter.limit) === limit ? 'selected' : ''}>${limit === 0 ? 'Todos' : limit}</option>`).join('')}
              </select>
            </label>
          </div>
          <div class="table-wrap"><table>
            <thead><tr><th>Número</th><th>Candidato</th><th>Ações</th></tr></thead>
            <tbody>${visibleCandidates.map((item) => `
              <tr>
                <td>${escapeHtml(item.numero)}</td>
                <td><strong>${escapeHtml(item.nome)}</strong><br><small>${escapeHtml(item.nome_urna)} · ${escapeHtml(item.cargo)}</small></td>
                <td><button type="button" class="secondary edit-candidate" data-id="${item.id}">Editar</button> <button type="button" class="danger delete-candidate" data-id="${item.id}">Excluir</button></td>
              </tr>
            `).join('') || '<tr><td colspan="4">Nenhum candidato neste quadro.</td></tr>'}</tbody>
          </table></div>
        </section>
      `;
    }).join('') || '<div class="panel"><p>Nenhum candidato encontrado.</p></div>';
  }

  searchInput.addEventListener('input', renderCandidateRows);
  officeFilter.addEventListener('change', renderCandidateRows);
  boardsContainer.addEventListener('input', (event) => {
    if (!event.target.classList.contains('candidate-board-search')) return;
    const category = event.target.dataset.category;
    const cursorStart = event.target.selectionStart;
    const cursorEnd = event.target.selectionEnd;
    boardFilters[category] = { ...(boardFilters[category] || { limit: 10 }), search: event.target.value };
    renderCandidateRows();
    const refreshedInput = [...boardsContainer.querySelectorAll('.candidate-board-search')]
      .find((input) => input.dataset.category === category);
    if (refreshedInput) {
      refreshedInput.focus();
      refreshedInput.setSelectionRange(cursorStart, cursorEnd);
    }
  });
  boardsContainer.addEventListener('change', (event) => {
    if (!event.target.classList.contains('candidate-board-limit')) return;
    const category = event.target.dataset.category;
    boardFilters[category] = { ...(boardFilters[category] || { search: '' }), limit: Number(event.target.value) };
    renderCandidateRows();
  });
  boardsContainer.addEventListener('click', (event) => {
    const edit = event.target.closest('.edit-candidate');
    const remove = event.target.closest('.delete-candidate');
    if (edit) {
      const item = state.candidates.find((candidate) => String(candidate.id) === edit.dataset.id);
      const form = document.getElementById('candidate-form');
      Object.entries(item || {}).forEach(([key, value]) => { if (form.elements[key]) form.elements[key].value = value ?? ''; });
      document.getElementById('candidate-form-title').textContent = 'Alterar candidato';
      document.getElementById('cancel-candidate-edit').hidden = false;
    }
    if (remove) removeResource(`/candidates/${remove.dataset.id}`, 'o candidato', renderCandidatesView);
  });
  renderCandidateRows();
}

async function createSection(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const payload = {
    eleicao_id: Number(state.selectedElectionId),
    numero: Number(form.get('numero') || 0),
    urna: Number(form.get('urna') || 0),
    local: String(form.get('local') || '').trim(),
    zona: String(form.get('zona') || '').trim(),
    municipio: String(form.get('municipio') || '').trim(),
    eleitores_aptos: Number(form.get('eleitores_aptos') || 0),
    status: form.get('status') || 'Aguardando',
  };

  try {
    const sectionId = form.get('id');
    await apiFetch(sectionId ? `/sections/${sectionId}` : '/sections', { method: sectionId ? 'PUT' : 'POST', body: JSON.stringify(payload) });
    await loadAppData();
    render();
  } catch (error) {
    alert(error.message);
  }
}

function renderSectionsView() {
  const panel = document.getElementById('content-panel');
  panel.innerHTML = `
    <div class="grid grid-2">
      <div class="panel card" style="padding:18px;">
        <h3 id="section-form-title">Cadastro de seções/urnas</h3>
        <form id="section-form" class="form-grid">
          <input type="hidden" name="id" />
          <label>Número ou nome da seção<input name="numero" type="text" maxlength="100" placeholder="Ex.: 101 ou Anexo da Escola Central" required /></label>
          <label>Número da urna<input name="urna" type="number" required /></label>
          <label>Local<input name="local" required /></label>
          <label>Zona eleitoral<input name="zona" required /></label>
          <label>Município<input name="municipio" required /></label>
          <label>Eleitores aptos<input name="eleitores_aptos" type="number" min="0" required /></label>
          <label>Status<select name="status"><option>Aguardando</option><option>Em apuração</option><option>Apurada</option><option>Conferida</option></select></label>
          <div style="grid-column:1 / -1;"><button class="primary" type="submit">Salvar seção</button></div>
        </form>
      </div>

      <div class="panel card" style="padding:18px;">
        <h3>Seções cadastradas</h3>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Seção</th><th>Urna</th><th>Local</th><th>Status</th><th>Ações</th></tr></thead>
            <tbody>
              ${state.sections.map((item) => `
                <tr>
                  <td>${escapeHtml(item.numero)}</td>
                  <td>${escapeHtml(item.urna)}</td>
                  <td>${escapeHtml(item.local)}</td>
                  <td>${escapeHtml(item.status)}</td>
                  <td><button type="button" class="secondary edit-section" data-id="${item.id}">Editar</button> <button type="button" class="danger delete-section" data-id="${item.id}">Excluir</button></td>
                </tr>
              `).join('') || '<tr><td colspan="4">Nenhuma seção cadastrada.</td></tr>'}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;

  document.getElementById('section-form').addEventListener('submit', createSection);
  document.querySelectorAll('.edit-section').forEach((button) => button.addEventListener('click', () => {
    const item = state.sections.find((section) => String(section.id) === button.dataset.id);
    const form = document.getElementById('section-form');
    Object.entries(item || {}).forEach(([key, value]) => { if (form.elements[key]) form.elements[key].value = value ?? ''; });
    document.getElementById('section-form-title').textContent = 'Alterar seção/urna';
  }));
  document.querySelectorAll('.delete-section').forEach((button) => button.addEventListener('click', () => removeResource(`/sections/${button.dataset.id}`, 'a seção', renderSectionsView)));
}

async function createApuracao(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const secaoId = Number(form.get('secao_id'));
  const votos = state.candidates.map((candidate) => ({
    candidato_id: candidate.id,
    quantidade: Number(form.get(`votos_${candidate.id}`) || 0),
  })).filter((vote) => vote.quantidade > 0);
  const votosValidos = votos.reduce((total, vote) => total + vote.quantidade, 0);

  const payload = {
    eleicao_id: Number(state.selectedElectionId),
    secao_id: secaoId,
    comparecimento: Number(form.get('comparecimento') || 0),
    abstencoes: Number(form.get('abstencoes') || 0),
    votos_validos: votosValidos,
    votos_brancos: Number(form.get('votos_brancos') || 0),
    votos_nulos: Number(form.get('votos_nulos') || 0),
    status: 'Aguardando',
    votos,
    usuario_lancamento: state.user?.id,
  };

  try {
    const apuracaoId = form.get('id');
    await apiFetch(apuracaoId ? `/apuracao/${apuracaoId}` : '/apuracao', { method: apuracaoId ? 'PUT' : 'POST', body: JSON.stringify(payload) });
    await loadAppData();
    render();
    alert('Votos salvos. A seção foi finalizada e marcada como apurada.');
  } catch (error) {
    alert(error.message);
  }
}

function renderApuracaoView() {
  const panel = document.getElementById('content-panel');
  const categoryOrder = ['Governo', 'Deputado Federal', 'Deputado Estadual', 'Senado'];
  const categoryFor = (candidate) => {
    const cargo = String(candidate.cargo || '').toLowerCase();
    if (cargo.includes('vice') && cargo.includes('govern')) return 'Governo';
    if (cargo.includes('govern')) return 'Governo';
    if (cargo.includes('deputado') && cargo.includes('federal')) return 'Deputado Federal';
    if (cargo.includes('deputado') && cargo.includes('estadual')) return 'Deputado Estadual';
    if (cargo.includes('senad')) return 'Senado';
    return candidate.cargo || 'Outros cargos';
  };
  const groupedCandidates = state.candidates.reduce((groups, candidate) => {
    const category = categoryFor(candidate);
    if (!groups[category]) groups[category] = [];
    groups[category].push(candidate);
    return groups;
  }, {});
  const categories = Object.keys(groupedCandidates).sort((left, right) => {
    const leftIndex = categoryOrder.indexOf(left);
    const rightIndex = categoryOrder.indexOf(right);
    return (leftIndex === -1 ? categoryOrder.length : leftIndex) - (rightIndex === -1 ? categoryOrder.length : rightIndex) || left.localeCompare(right);
  });
  const candidatePanels = categories.map((category, index) => `
    <section class="panel card manual-candidate-group" data-panel="${index}" style="padding:14px; margin-top:${index ? '14px' : '0'}; border-left:5px solid ${['#0f766e', '#1d4ed8', '#7c3aed', '#b45309'][index % 4]};">
      <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; margin-bottom:12px;">
        <h4 style="margin:0;">${escapeHtml(category).toUpperCase()}</h4>
        <small class="manual-group-count"></small>
        <label class="manual-group-limit">Mostrar
          <select class="manual-candidate-limit" data-panel="${index}" aria-label="Quantidade de candidatos exibidos em ${escapeHtml(category)}">
            ${[10, 20, 50, 100, 0].map((limit) => `<option value="${limit}">${limit === 0 ? 'Todos' : limit}</option>`).join('')}
          </select>
        </label>
      </div>
      ${groupedCandidates[category].sort((left, right) => {
        const leftIsVice = String(left.cargo || '').toLowerCase().includes('vice');
        const rightIsVice = String(right.cargo || '').toLowerCase().includes('vice');
        if (leftIsVice !== rightIsVice) return leftIsVice ? 1 : -1;
        return Number(left.numero || 0) - Number(right.numero || 0);
      }).map((candidate) => `
        <div class="form-grid manual-candidate-row" data-panel="${index}" data-search-text="${escapeHtml([candidate.numero, candidate.nome, candidate.nome_urna, candidate.partido, candidate.cargo].join(' '))}" style="grid-template-columns:1fr 1fr 140px; margin-bottom:8px; align-items:center;">
          <span>${escapeHtml(candidate.numero)} - ${escapeHtml(candidate.nome)}</span>
          <span></span>
          ${String(candidate.cargo || '').toLowerCase().includes('vice') ? '<span style="color:var(--muted);">Vice-Governador · sem votação separada</span>' : '<label>Votos<input class="quick-vote" type="number" min="0" name="votos_${candidate.id}" value="0" /></label>'}
        </div>
      `).join('')}
    </section>
  `).join('');

  panel.innerHTML = `
    <div class="panel card" style="padding:18px;">
      <h3 id="apuracao-form-title">Lançamento de votos por seção</h3>
      <form id="apuracao-form" class="form-grid">
        <input type="hidden" name="id" />
        <div style="grid-column:1 / -1; display:flex; justify-content:space-between; align-items:end; gap:12px; flex-wrap:wrap; padding:12px; background:#eff6ff; border:1px solid #bfdbfe; border-radius:10px;">
          <label style="flex:1; min-width:240px;">Buscar seção por número, urna ou local<input id="section-search" type="search" placeholder="Digite o número da seção, urna, escola ou município" autocomplete="off" /><small id="section-search-feedback" aria-live="polite"></small></label>
          <label style="flex:1; min-width:260px;">Seção<select name="secao_id">${state.sections.map((section) => `<option value="${section.id}" data-search-text="${escapeHtml([section.numero, section.urna, section.local, section.zona, section.municipio].join(' '))}">Seção ${escapeHtml(section.numero)} · Urna ${escapeHtml(section.urna)} · ${escapeHtml(section.local)} · ${escapeHtml(section.municipio)}</option>`).join('') || '<option value="">Nenhuma seção</option>'}</select></label>
          <button class="success" type="submit">Salvar apuração da seção</button>
        </div>
        <label>Comparecimento<input name="comparecimento" type="number" min="0" value="0" required /></label>
        <label>Abstenções<input name="abstencoes" type="number" min="0" value="0" /></label>
        <label>Votos válidos<input name="votos_validos" type="number" min="0" value="0" readonly /><small>Soma calculada automaticamente pelos votos dos candidatos.</small></label>
        <label>Brancos<input name="votos_brancos" type="number" min="0" value="0" /></label>
        <label>Nulos<input name="votos_nulos" type="number" min="0" value="0" /></label>
        <div style="grid-column:1 / -1;">
          <div style="display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap;">
            <h4 style="margin:0;">Votos por candidato</h4>
            <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
              <strong>Total digitado: <span id="manual-votes-total">0</span></strong>
              <button class="secondary" type="button" id="clear-manual-votes">Zerar votos</button>
            </div>
          </div>
          <div class="manual-search-wrap">
            <label for="manual-candidate-search">Buscar candidato por número, nome ou partido</label>
            <input id="manual-candidate-search" type="search" placeholder="Ex.: 12345 ou nome do candidato" autocomplete="off" />
            <small id="manual-search-result-count" aria-live="polite">${state.candidates.length} candidatos</small>
          </div>
          ${candidatePanels || '<p>Cadastre candidatos antes de lançar a apuração.</p>'}
          <p id="manual-search-empty" class="manual-search-empty" hidden>Nenhum candidato corresponde à busca.</p>
        </div>
        <div style="grid-column:1 / -1; display:flex; justify-content:flex-end;"><button class="primary" type="submit">Salvar apuração da seção</button></div>
      </form>
    </div>
    <div class="panel card" style="padding:18px; margin-top:20px;">
      <h3>Apurações registradas</h3>
      <div class="table-wrap"><table>
        <thead><tr><th>Seção</th><th>Comparecimento</th><th>Válidos</th><th>Brancos</th><th>Nulos</th><th>Status</th><th>Ações</th></tr></thead>
        <tbody>${(state.apuracoes || []).map((item) => `<tr>
          <td>${escapeHtml(item.secao_numero || item.secao_id)}</td><td>${escapeHtml(item.comparecimento)}</td>
          <td>${escapeHtml(item.votos_validos)}</td><td>${escapeHtml(item.votos_brancos)}</td>
          <td>${escapeHtml(item.votos_nulos)}</td><td>${escapeHtml(item.status)}</td>
          <td><button type="button" class="secondary edit-apuracao" data-id="${item.id}" data-secao="${item.secao_id}">Editar</button> <button type="button" class="danger delete-apuracao" data-id="${item.id}">Excluir</button></td>
        </tr>`).join('') || '<tr><td colspan="7">Nenhuma apuração registrada.</td></tr>'}</tbody>
      </table></div>
    </div>
  `;

  document.getElementById('apuracao-form').addEventListener('submit', createApuracao);
  const apuracaoForm = document.getElementById('apuracao-form');
  const sectionSelect = apuracaoForm.elements.secao_id;
  const sectionSearch = document.getElementById('section-search');
  const sectionSearchFeedback = document.getElementById('section-search-feedback');
  const searchableSectionOptions = [...sectionSelect.options].filter((option) => option.value);
  const normalizeSectionSearch = (value) => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  const filterSections = () => {
    const term = normalizeSectionSearch(sectionSearch.value);
    let matches = 0;
    searchableSectionOptions.forEach((option) => {
      const match = normalizeSectionSearch(option.dataset.searchText).includes(term);
      if (match) matches += 1;
      option.hidden = Boolean(term && !match && option.value !== sectionSelect.value);
    });
    sectionSearchFeedback.textContent = term
      ? `${matches} seção${matches === 1 ? '' : 'ões'} encontrada${matches === 1 ? '' : 's'} para selecionar`
      : `${searchableSectionOptions.length} seção${searchableSectionOptions.length === 1 ? '' : 'ões'} cadastrada${searchableSectionOptions.length === 1 ? '' : 's'}`;
  };
  sectionSearch.addEventListener('input', filterSections);
  filterSections();
  const formTitle = document.getElementById('apuracao-form-title');
  const loadSectionApuracao = async () => {
    if (!sectionSelect.value) return;
    try {
      const existing = await apiFetch(`/apuracao/section/${sectionSelect.value}`);
      if (!existing) {
        apuracaoForm.elements.id.value = '';
        formTitle.textContent = 'Lançamento de votos por seção';
        ['comparecimento', 'abstencoes', 'votos_validos', 'votos_brancos', 'votos_nulos'].forEach((name) => {
          apuracaoForm.elements[name].value = 0;
        });
        voteInputs.forEach((input) => { input.value = 0; });
        updateVoteTotal();
        return;
      }
      apuracaoForm.elements.id.value = existing.id;
      formTitle.textContent = 'Editar lançamento da seção';
      ['comparecimento', 'abstencoes', 'votos_validos', 'votos_brancos', 'votos_nulos'].forEach((name) => {
        apuracaoForm.elements[name].value = existing[name] ?? 0;
      });
      voteInputs.forEach((input) => { input.value = 0; });
      (existing.votos || []).forEach((vote) => {
        if (apuracaoForm.elements[`votos_${vote.candidato_id}`]) apuracaoForm.elements[`votos_${vote.candidato_id}`].value = vote.quantidade;
      });
      updateVoteTotal();
    } catch (error) {
      alert(error.message);
    }
  };
  sectionSelect.addEventListener('change', loadSectionApuracao);
  const voteInputs = [...document.querySelectorAll('#apuracao-form .quick-vote')];
  const candidateSearch = document.getElementById('manual-candidate-search');
  const candidateRows = [...document.querySelectorAll('#apuracao-form .manual-candidate-row')];
  const candidateGroups = [...document.querySelectorAll('#apuracao-form .manual-candidate-group')];
  const groupLimits = [...document.querySelectorAll('#apuracao-form .manual-candidate-limit')];
  const normalizeSearch = (value) => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  const filterManualCandidates = () => {
    const term = normalizeSearch(candidateSearch.value);
    let matchingCount = 0;
    let visibleCount = 0;
    candidateGroups.forEach((group) => {
      const rows = candidateRows.filter((row) => row.dataset.panel === group.dataset.panel);
      const matchingRows = rows.filter((row) => normalizeSearch(row.dataset.searchText).includes(term));
      const limit = Number(group.querySelector('.manual-candidate-limit').value || 10);
      const visibleRows = limit === 0 ? matchingRows : matchingRows.slice(0, limit);
      const visibleSet = new Set(visibleRows);
      rows.forEach((row) => { row.hidden = !visibleSet.has(row); });
      group.hidden = matchingRows.length === 0;
      matchingCount += matchingRows.length;
      visibleCount += visibleRows.length;
      group.querySelector('.manual-group-count').textContent = limit > 0 && matchingRows.length > limit
        ? `Exibindo ${visibleRows.length} de ${matchingRows.length}`
        : `${visibleRows.length} candidato${visibleRows.length === 1 ? '' : 's'}`;
    });
    document.getElementById('manual-search-result-count').textContent = term
      ? `Exibindo ${visibleCount} de ${matchingCount} encontrados`
      : `Exibindo ${visibleCount} de ${candidateRows.length} candidatos`;
    document.getElementById('manual-search-empty').hidden = matchingCount > 0;
  };
  candidateSearch.addEventListener('input', filterManualCandidates);
  groupLimits.forEach((limit) => limit.addEventListener('change', filterManualCandidates));
  filterManualCandidates();
  candidateSearch.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter') return;
    event.preventDefault();
    const firstMatch = voteInputs.find((input) => !input.closest('.manual-candidate-row').hidden);
    if (firstMatch) firstMatch.focus();
  });
  const totalVotes = document.getElementById('manual-votes-total');
  const updateVoteTotal = () => {
    const total = voteInputs.reduce((sum, input) => sum + Number(input.value || 0), 0);
    totalVotes.textContent = formatCurrency(total);
    apuracaoForm.elements.votos_validos.value = total;
  };
  voteInputs.forEach((input, index) => {
    input.addEventListener('input', updateVoteTotal);
    input.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter') return;
      event.preventDefault();
      const nextInput = voteInputs.slice(index + 1).find((input) => !input.closest('.manual-candidate-row').hidden);
      if (nextInput) nextInput.focus();
      else document.querySelector('#apuracao-form button[type="submit"]').focus();
    });
  });
  if (candidateRows.length) candidateSearch.focus();
  document.getElementById('clear-manual-votes').addEventListener('click', () => {
    voteInputs.forEach((input) => { input.value = 0; });
    updateVoteTotal();
    const firstVisibleVoteInput = voteInputs.find((input) => !input.closest('.manual-candidate-row').hidden);
    if (firstVisibleVoteInput) firstVisibleVoteInput.focus();
  });
  loadSectionApuracao();
  document.querySelectorAll('.edit-apuracao').forEach((button) => button.addEventListener('click', async () => {
    try {
      const item = await apiFetch(`/apuracao/section/${button.dataset.secao}`);
      const form = document.getElementById('apuracao-form');
      Object.entries(item || {}).forEach(([key, value]) => { if (form.elements[key]) form.elements[key].value = value ?? ''; });
      (item?.votos || []).forEach((vote) => { if (form.elements[`votos_${vote.candidato_id}`]) form.elements[`votos_${vote.candidato_id}`].value = vote.quantidade; });
      updateVoteTotal();
      document.getElementById('apuracao-form-title').textContent = 'Alterar apuração';
    } catch (error) { alert(error.message); }
  }));
  document.querySelectorAll('.delete-apuracao').forEach((button) => button.addEventListener('click', () => removeResource(`/apuracao/${button.dataset.id}`, 'a apuração', renderApuracaoView)));
}

function renderAuditView() {
  const panel = document.getElementById('content-panel');
  panel.innerHTML = `
    <div class="panel card" style="padding:18px;">
      <h3>Auditoria</h3>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Usuário</th><th>Ação</th><th>Tabela</th><th>Data</th></tr></thead>
          <tbody>
            ${state.audit.map((item) => `
              <tr>
                <td>${escapeHtml(item.usuario_nome || item.usuario_id || 'Sistema')}</td>
                <td>${escapeHtml(item.acao)}</td>
                <td>${escapeHtml(item.tabela)}</td>
                <td>${escapeHtml(item.created_at ? new Date(item.created_at).toLocaleString('pt-BR') : '')}</td>
              </tr>
            `).join('') || '<tr><td colspan="4">Sem registros de auditoria.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function renderActiveView() {
  if (state.activeView !== 'dashboard' && dashboardRefreshTimer) {
    window.clearInterval(dashboardRefreshTimer);
    dashboardRefreshTimer = null;
  }
  if (!state.activeView) state.activeView = 'dashboard';
  if (state.activeView === 'dashboard') renderDashboardView();
  if (state.activeView === 'eleicoes') renderElectionsView();
  if (state.activeView === 'candidatos') renderCandidatesView();
  if (state.activeView === 'secoes') renderSectionsView();
  if (state.activeView === 'apuracao') renderApuracaoView();
  if (state.activeView === 'relatorios') renderReportsView();
  if (state.activeView === 'importacao') renderImportView();
  if (state.activeView === 'audit') renderAuditView();

  const pageInfo = {
    dashboard: ['Visão geral', 'Acompanhe o andamento e os principais números da eleição.'],
    eleicoes: ['Eleições', 'Cadastre e gerencie as eleições do sistema.'],
    candidatos: ['Candidatos', 'Organize candidaturas, partidos e cargos em disputa.'],
    secoes: ['Seções eleitorais', 'Gerencie os locais, urnas e eleitorado de cada seção.'],
    apuracao: ['Lançamento manual', 'Registre os resultados recebidos por seção eleitoral.'],
    relatorios: ['Relatórios', 'Consulte os totais e exporte os resultados da eleição.'],
    importacao: ['Importação de dados', 'Envie um arquivo para conferir os dados antes da importação.'],
    audit: ['Auditoria', 'Consulte o histórico de alterações realizadas no sistema.'],
  }[state.activeView];
  if (pageInfo) {
    document.getElementById('content-panel').insertAdjacentHTML('afterbegin', `
      <header class="page-heading"><div><span class="page-eyebrow">SISTEMA DE APURAÇÃO</span><h1>${pageInfo[0]}</h1><p>${pageInfo[1]}</p></div></header>
    `);
  }
}

async function render() {
  if (!state.token || !state.user) {
    renderLogin();
    return;
  }

  try {
    renderShell();
    await loadAppData();
    renderActiveView();
  } catch (error) {
    alert(error.message);
  }
}

render();
